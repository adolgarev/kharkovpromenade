-module(big_queue_app).
-export([start/0]).


start() ->
    big_queue:start(),
    inets:start(),
    big_queue_http:start().

