#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stddef.h>


#include "util.h"





IHASH*
ihashnew(size_t size, uint_t nbuckets) {

    IHASH  *h;

    h = malloc(sizeof(IHASH));
    if (h == NULL)
        return NULL;
    memset(h, 0, sizeof(IHASH));



    h->buckets = malloc(nbuckets * sizeof(IHASHE*));
    if (!h->buckets)
        return NULL;
    memset(h->buckets, 0, nbuckets * sizeof(IHASHE*));


    h->size = size;
    h->nbuckets = nbuckets;

    return h;
}



void
ihashdel(IHASH *h) {
    IHASHE    **bucket;
    IHASHE     *p;
    IHASHE     *n;

    for (bucket = h->buckets; bucket < h->buckets + h->nbuckets; bucket++) {
        for (p = *bucket; p; ) {
            n = p->next;

            free(p);
            p = n;
        }
    }

    free(h->buckets);
    free(h);
}



void
ihashdel2(IHASH *h, void *data) {
    IHASHE *elt;

    elt = (IHASHE*)((char*)data - offsetof(IHASHE, data));

    if (elt->prev) {
        *elt->prev = elt->next;
    }
    if (elt->next) {
        elt->next->prev = elt->prev;
    }

    free(elt);
}


void*
ihashput(IHASH *h, uint_t key_hash) {
    IHASHE     *elt, **bucket;

    bucket = h->buckets + (key_hash % h->nbuckets);

    elt = malloc(sizeof(IHASHE) + h->size);


    elt->next           = *bucket;
    elt->prev           = bucket;
    if (*bucket)
        (*bucket)->prev   = &elt->next;
    *bucket             = elt;

    return elt->data;
}


void*
ihashput2(IHASH *h, uint_t key_hash, size_t size) {
    IHASHE     *elt, **bucket;

    bucket = h->buckets + (key_hash % h->nbuckets);

    elt = malloc(sizeof(IHASHE) + size);


    elt->next           = *bucket;
    elt->prev           = bucket;
    if (*bucket)
        (*bucket)->prev   = &elt->next;
    *bucket             = elt;

    return elt->data;
}


void*
ihashget(IHASH *h, uint_t key_hash) {
    
    IHASHE     *elt;
    
    key_hash = key_hash % h->nbuckets;
    elt = h->buckets[key_hash];

    if (elt)
        return elt->data;

    return NULL;
}

void*
ihashget2(IHASH *h, void *data) {
    IHASHE *elt;

    elt = (IHASHE*)((char*)data - offsetof(IHASHE, data));

    if (elt->next)
        return elt->next->data;

    return NULL;
}


unsigned long
ihashkey2(void *data, size_t len) {
    unsigned long hash = 0;
    char   *p;

    p = data;

    while (p < (char *) data + len) {
        hash = ihashkey(hash, *p++);
    }

    return hash;
}


unsigned long
ihashkey3(void *data, size_t len) {
    unsigned long hash = 0;
    char   *p;

    p = data;

    while (p < (char *) data + len && *p != '\0') {
        hash = ihashkey(hash, *p++);
    }

    return hash;
}


















IPOOL*
ipoolnew(uint_t nbuckets, uint_t n) {
    IPOOL  *pool;
    
    /*size = size - size % sizeof(IPOOLE);*/

    pool = malloc(sizeof(IPOOL));
    if (!pool)
        return NULL;
    memset(pool, 0, sizeof(IPOOL));

    pool->elts = malloc(n * sizeof(IPOOLE*));
    if (pool->elts == NULL)
        return NULL;
    memset(pool->elts, 0, n * sizeof(IPOOLE*));


    pool->eltkeys = ihashnew(0, n * 2);
    pool->keys    = ihashnew(sizeof(IKEY), nbuckets);
    pool->nelts   = n;
    pool->nalloc  = 0;

    return pool;
}


void
ipooldel(IPOOL *pool) {
    ihashdel(pool->keys);
    ihashdel(pool->eltkeys);

    free(pool->elts);

    free(pool);
}

IPOOLE**
ipoolcalloc(IPOOL *pool, char *key, eltk_t elt_key, size_t size) {
    IPOOLE         *p;
    uint_t          key_hash;
    IKEY           *pk;


    
    if (pool->nalloc == pool->nelts) {
        pool->nalloc = 0;
    }


    p = pool->elts[pool->nalloc];
    if (p) {
        if (!p->next)
            ihashdel2(pool->keys, p->key);

        ihashdel2(pool->eltkeys, p);
    }
    

    p = ihashput2(pool->eltkeys, elt_key, sizeof(IPOOLE) + size);
    if (!p)
        return NULL;
    memset(p, 0, sizeof(IPOOLE) + size);
    p->len = size;
    pool->elts[pool->nalloc] = p;


    key_hash = ihashkey3(key, KEYLEN);
    for (pk = ihashget(pool->keys, key_hash); pk && strncmp(pk->data, key, KEYLEN); pk = ihashget2(pool->keys, pk))
        ;

    if (!pk) {
        pk = ihashput(pool->keys, key_hash);
        strcpy(pk->data, key);
    }
    else {
        (*pk->last)->next = p;
    }
    
    pk->last = pool->elts + pool->nalloc;
    p->key = pk;
    p->elt_key = elt_key;


    return pool->elts + pool->nalloc++;
}



