-module(big_queue).
-export([start/0, stop/0, init/1]).
-export([write/2, read/1, start_test/1]).

start() ->
    SharedLib = "big_queue_drv",
    case erl_ddll:load_driver(".", SharedLib) of
        ok -> ok;
        {error, already_loaded} -> ok;
        _ -> exit({error, could_not_load_driver})
    end,
    spawn(?MODULE, init, [SharedLib]).

init(SharedLib) ->
    register(?MODULE, self()),
    Port = open_port({spawn, SharedLib}, [binary]),
    loop(Port).

stop() ->
    ?MODULE ! stop.

write(QueueId, Msg) ->
    ?MODULE ! {write, self(), QueueId, Msg},
    receive
        {result, Result} ->
            Result
    end.

%Types
% read(L) -> Res
% L = [Queue]
% Queue = {QueueId, N}
% Res = [R]
% R = {QueueId, N, [Message]}
read(L) ->
    ?MODULE ! {read, self(), L},
    receive
        {result, Result} ->
            Result
    end.


loop(Port) ->
    receive
        {write, Pid, QueueId, Msg} ->
            port_command(Port, term_to_binary({write, QueueId, Msg})),
            receive
                {Port, {data, Data}} ->
                    Pid ! {result, binary_to_term(Data)}
            end,
            loop(Port);
        {read, Pid, L} ->
            port_command(Port, term_to_binary({read, L})),
            receive
                {Port, {data, Data}} ->
                    Pid ! {result, binary_to_term(Data)}
            end,
            loop(Port);
        stop ->
            port_close(Port),
            exit(normal);
        {'EXIT', Port, Reason} ->
            io:format("~p ~n", [Reason]),
            exit(port_terminated)
    end.







start_test(N) ->
    S1 = now_seconds(),
    write_test(N),
    S2 = now_seconds(),
    [{_, M, _}|_] = read([{"aaaaaaaaaaaaaaabbbbbbbbbbbbbbbb", -1}]),
    read_test(N, M - 100),
    S3 = now_seconds(),
    io:format("write:~w read:~w~n", [S2 - S1, S3 - S2]).

now_seconds() ->
    {MegaSecs, Secs, MicroSecs} = now(),
    MegaSecs * 1000000 + Secs + MicroSecs / 1000000.

write_test(0) ->
    ok;
write_test(N) ->
    write("aaaaaaaaaaaaaaabbbbbbbbbbbbbbbb", N),
    write_test(N - 1).

read_test(0, _M) ->
    ok;
read_test(N, M) ->
    read([{"aaaaaaaaaaaaaaabbbbbbbbbbbbbbbb", M}]),
    read_test(N - 1, M).
