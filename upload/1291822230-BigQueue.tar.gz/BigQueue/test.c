#include "util.h"

int
main(int argc, char **argv) {
    
    {
        IHASH  *h;
        int    *p;

        h = ihashnew(sizeof(int), 10);

        *(int*)ihashput(h, 1) = 3;
        *(int*)ihashput(h, 11) = 4;
        *(int*)ihashput(h, 3) = 5;

        p = ihashget(h, 1);
        /*p = ihashget2(h, p);*/

        ihashdel2(h, p);

        ihashdel(h);
    }


    {
        IPOOL      *pool;
        IPOOLE    **p;


        pool = ipoolnew(100000, 5);


        p = ipoolcalloc(pool, "a1", 1, 1000);
        p = ipoolcalloc(pool, "a1", 2, 100);
        p = ipoolcalloc(pool, "a2", 3, 1000);
        p = ipoolcalloc(pool, "a2", 4, 100);
        p = ipoolcalloc(pool, "a3", 5, 1000);
        p = ipoolcalloc(pool, "a3", 6, 100);
        p = ipoolcalloc(pool, "a3", 7, 100);
        

        ipooldel(pool);
    }

    return 0;
}


