-module(big_queue_http).
-include_lib("inets/src/http_server/httpd.hrl").
-export([start/0, do/1]).
-define(JSCALLBACK, "konferoAjaxCallback").


start() ->
    inets:start(httpd, [
        {port, 9000}, {server_name,"big_queue"}, {server_root,"/tmp"}, {document_root,"/tmp"},
        {modules, [?MODULE]}, {max_clients, 100000}
    ]).

do(ModData) ->
    N = string:chr(ModData#mod.request_uri, $?),
    DocUri = list_to_existing_atom(string:substr(ModData#mod.request_uri, 2, N - 2)),
    Data = httpd:parse_query(string:substr(ModData#mod.request_uri, N + 1)),
    case catch r(DocUri, Data) of
        {'EXIT', Error} ->
            {proceed, [{response, {500, io_lib:format("~w", [Error])}}]};
        Res ->
            {proceed, [{response, Res}]}
    end.


%TODO source user
r('sendMessage', Data) ->
    L = lists:map(fun({X,Y}) ->
        {X, unicode:characters_to_list(list_to_binary(Y))}
    end, Data),
    L1 = [{"time", nows()}|lists:keydelete("requestId", 1, L)],
    M = dict:from_list(L1),
    {ok, QueueId} = dict:find("queueId", M),
    N = big_queue:write(QueueId, L1),
    {C, Res} = case lists:keyfind("requestId", 1, Data) of
        false -> {"text/plain", integer_to_list(N)};
        {_, RequestId} -> {"text/javascript", ?JSCALLBACK ++ "('" ++ RequestId ++ "', '" ++ integer_to_list(N) ++ "');"}
    end,
    {response, [{code, 200}, {content_length, integer_to_list(length(Res))}, {content_type, C}], Res};

r('getMessages', Data) ->
    L1 = lists:foldl(fun
        ({"queueId",Y}, Acc) -> [Y|Acc];
        (_, Acc) -> Acc
    end, [], Data),
    L2 = lists:foldl(fun
        ({"messageNumber",Y}, Acc) -> [list_to_integer(Y)|Acc];
        (_, Acc) -> Acc
    end, [], Data),
    Zipped = lists:zip(L1, L2),
    R = big_queue:read(Zipped),
    R1 = {array, lists:map(fun({QueueId, N, Messages}) ->
        {struct, [{queueId, QueueId}, {messageNumber, N}, {messages, {array, lists:map(fun(M) ->
            {struct, html_encode(M)}
        end, Messages)}}]}
    end, R)},
    {_, RequestId} = lists:keyfind("requestId", 1, Data),
    Res = ?JSCALLBACK ++ "('" ++ RequestId ++ "', '" ++ lists:flatten(json:encode(R1)) ++ "');",
    {response, [{code, 200}, {content_length, integer_to_list(length(Res))}, {content_type, "text/javascript"}], Res}.


html_encode(M) ->
    lists:map(fun
        ({Key,Val}) when is_list(Val) ->
            {Key, lists:flatten(lists:map(fun
                (C) when ((C >= 48) and (C =< 57)) orelse ((C >= 65) and (C =< 90)) orelse ((C >= 97) and (C =< 122)) orelse (C == $.) orelse (C == $\n) orelse (C == $\r) orelse (C == $\t) -> C;
                (C) -> "&#" ++ integer_to_list(C) ++ ";"
            end, Val))};
        (X) ->
            X
    end, M).


nows() ->
    {MegaSecs, Secs, MicroSecs} = now(),
    trunc(MegaSecs * 1000000000 + Secs * 1000 + MicroSecs / 1000).
