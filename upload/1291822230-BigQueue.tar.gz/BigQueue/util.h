#ifndef UTIL_H
#define UTIL_H



#include <inttypes.h>
#include <sys/types.h>
#include <sys/stat.h> 




typedef intptr_t        int_t;
typedef uintptr_t       uint_t;
typedef intptr_t        flag_t;
typedef long            eltk_t;






















typedef struct IHASHES  IHASHE;

struct IHASHES {
    IHASHE    **prev;
    IHASHE     *next;
    u_char      data[0];
};



typedef struct {
    size_t      size;       /* size of an element */
    IHASHE    **buckets;    /* pointers to elts */
    uint_t      nbuckets;   /* number of buckets */
} IHASH;




IHASH *ihashnew(size_t size, uint_t nbuckets);
void ihashdel(IHASH *h);
void ihashdel2(IHASH *h, void *data);
void *ihashput(IHASH *h, uint_t key_hash);
void *ihashput2(IHASH *h, uint_t key_hash, size_t size);
void *ihashget(IHASH *h, uint_t key_hash);
void *ihashget2(IHASH *h, void *data);

#define ihashkey(k, a)     ((a) + ((k) << 6) + ((k) << 16) - (k))
unsigned long ihashkey2(void *data, size_t len);
unsigned long ihashkey3(void *data, size_t len);











typedef struct IPOOLES  IPOOLE;


#define KEYLEN  160

typedef struct {
    IPOOLE    **last;
    char        data[KEYLEN];
} IKEY;


struct IPOOLES {
    IKEY           *key;
    eltk_t          elt_key;
    IPOOLE         *next;
    size_t          len;
    u_char          data[0];
};

typedef struct {
    IHASH          *keys;       /* queues keys */
    IHASH          *eltkeys;    /* elements ids */

    IPOOLE        **elts;
    uint_t          nelts;      /* number of used elements */
    uint_t          nalloc;     /* number of allocated elements */
} IPOOL;


IPOOL *ipoolnew(uint_t nbuckets, uint_t n);
void ipooldel(IPOOL *pool);
IPOOLE **ipoolcalloc(IPOOL *pool, char *key, eltk_t elt_key, size_t size);

















#endif
