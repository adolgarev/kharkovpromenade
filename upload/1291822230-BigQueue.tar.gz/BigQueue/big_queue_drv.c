#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "erl_driver.h"
#include "ei.h"

#include "util.h"






typedef struct {
    ErlDrvPort  port;
    IPOOL      *pool;
} IPORT;


static ErlDrvData idrvstart(ErlDrvPort, char*);
static void idrvstop(ErlDrvData);
static void idrvout(ErlDrvData, char*, int);



ErlDrvEntry driver_entry = {
    NULL,           /* F_PTR init, N/A */
    idrvstart,      /* L_PTR start, called when port is opened */
    idrvstop,       /* F_PTR stop, called when port is clsed */
    idrvout,        /* F_PTR output, called when erlang has sent */
    NULL,           /* F_PTR ready_input, called when input descriptor ready */
    NULL,           /* F_PTR ready_output, called when output descriptor ready */
    "big_queue_drv",      /* char *driver_name, the argument to open_port */
    NULL,           /* F_PTR finish, called when unloaded */
    NULL,           /* F_PTR control, port_command callback */
    NULL,           /* F_PTR timeout, reserved */
    NULL            /* F_PTR outputv, reserved */
};

DRIVER_INIT(big_queue_drv) {
    return &driver_entry;
}




















static ErlDrvData
idrvstart(ErlDrvPort port, char *buff) {
    IPORT *p;
    
    p = (IPORT*)driver_alloc(sizeof(IPORT));
    p->port = port;

    p->pool = ipoolnew(100000, 1000000);

    return (ErlDrvData)p;
}

static void
idrvstop(ErlDrvData port) {
    IPORT *p;

    p = (IPORT*)port;

    ipooldel(p->pool);
    driver_free((char*)p);
}

static void
idrvout(ErlDrvData data, char *buff, int bufflen) {
    IPORT          *p;
    IPOOL          *pool;
    char            buf[100];
    ei_x_buff       bufx;
    ei_x_buff      *x;
    char            key[KEYLEN];
    int             index_v;
    int            *index;
    int             r;

    p = (IPORT*)data;
    pool = p->pool;

    x = &bufx;
    ei_x_new(x);

    index_v = 0;
    index = &index_v;
    ei_decode_version(buff, index, &r);
    ei_decode_tuple_header(buff, index, &r);
    ei_decode_atom(buff, index, buf);

    if (strncmp(buf, "write", 5) == 0) {
        IPOOLE    **pe;
        eltk_t      n;

        ei_decode_string(buff, index, key);

        n = ihashkey2(buff + index_v, bufflen - index_v) << 1;
        pe = ipoolcalloc(pool, key, n, bufflen - index_v);
        memcpy((*pe)->data, buff + index_v, bufflen - index_v);

        index_v = 0;
        ei_x_encode_version(x);
        ei_x_encode_long(x, n);
    }
    else if (strncmp(buf, "read", 4) == 0) {
        int     i;
        int     arity;
        eltk_t  n;
        IPOOLE *pe;
        int     j;

        j = 0;
        ei_x_encode_version(x);
        ei_decode_list_header(buff, index, &arity);
        ei_x_encode_list_header(x, arity);
        for (i = 0; i < arity; i++) {
            ei_decode_tuple_header(buff, index, &r);
            ei_decode_string(buff, index, key);
            ei_decode_long(buff, index, &n);

            ei_x_encode_tuple_header(x, 3);
            ei_x_encode_string(x, key);

            if (n == -1) {
                uint_t          key_hash;
                IKEY           *pk;


                key_hash = ihashkey3(key, KEYLEN);
                for (pk = ihashget(pool->keys, key_hash); pk && strncmp(pk->data, key, KEYLEN); pk = ihashget2(pool->keys, pk))
                    ;

                if (!pk) {
                    ei_x_encode_long(x, -1);
                    ei_x_encode_empty_list(x);
                    continue;
                }

                ei_x_encode_long(x, (*pk->last)->elt_key + 1);
                ei_x_encode_empty_list(x);
                continue;
            }
            else {
                eltk_t      nn;

                nn = (n >> 1) << 1;
                for (pe = ihashget(pool->eltkeys, nn); pe && (pe->elt_key != nn || strncmp(key, pe->key->data, KEYLEN)); pe = ihashget2(pool->eltkeys, pe))
                    ;
                if (!pe) {
                    ei_x_encode_long(x, -1);
                    ei_x_encode_empty_list(x);
                    continue;
                }
            }

            ei_x_encode_long(x, (*pe->key->last)->elt_key + 1);
            if (n & 1)
                pe = pe->next;
            /* slow
            for (; pe; pe = pe->next) {
                ei_x_encode_list_header(x, 1);
                ei_x_append_buf(x, (char*)pe->data, pe->len);
            }*/
            {
                int num;
                IPOOLE *ppe;

                for (num = 0, ppe = pe; ppe; ppe = ppe->next)
                    num++;
                ei_x_encode_list_header(x, num);
                for (; pe; pe = pe->next) {
                    ei_x_append_buf(x, (char*)pe->data, pe->len);
                }
            }
            ei_x_encode_empty_list(x);
        }
        ei_x_encode_empty_list(x);
        ei_skip_term(buff, index);
    }





    driver_output(p->port, x->buff, x->index);

    ei_x_free(x);
}











