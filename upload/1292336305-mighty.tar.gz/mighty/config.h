
#define WORKERS         4

#define BACKLOG         10000
#define DEFAULTPOOLSIZE     (16*1024)
#define REQUESTHEADERSIZE   4096

#define PORT            9003

#define DOCUMENT_ROOT       "/home/adolgarev/public_html"
/*#define X_ACCEL_REDIRECT    "/files"*/


