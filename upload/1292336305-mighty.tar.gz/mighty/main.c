#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <netinet/tcp.h>





#include "config.h"
#include "http.h"






int         ICONNECTIONRCVBUF;








static  int         lock_fd;

#define write_lock(fd, offset, whence, len)     lock_reg(fd, F_SETLK, F_WRLCK, offset, whence, len)
#define writew_lock(fd, offset, whence, len)    lock_reg(fd, F_SETLKW, F_WRLCK, offset, whence, len)
#define un_lock(fd, offset, whence, len)        lock_reg(fd, F_SETLK, F_UNLCK, offset, whence, len)

int
lock_reg(int fd,  int cmd, int type, off_t offset, int whence, off_t len) {

    struct flock lock;

    lock.l_type     = type;
    lock.l_start    = offset;
    lock.l_whence   = whence;
    lock.l_len      = len;

    return fcntl(fd, cmd, &lock);
}








void
iacceptcb(struct ev_loop *loop, ev_io *w, int revents) {

    int                 new_fd;
    struct sockaddr_in  their_addr;
    socklen_t           sin_size;

    int val;




    sin_size = sizeof(their_addr);

    writew_lock(lock_fd, 0, SEEK_SET, 0);
    /*if (write_lock(lock_fd, 0, SEEK_SET, 0) == -1) {
        if (errno == EACCES || errno == EAGAIN)
            goto end;

        perror("write_lock");
        goto error;
    }*/

    if ((new_fd = accept(w->fd, (struct sockaddr *)&their_addr, &sin_size)) == -1) {

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            un_lock(lock_fd, 0, SEEK_SET, 0);
            goto end;
        }

        perror("accept");
        un_lock(lock_fd, 0, SEEK_SET, 0);
        goto error;
    }

    un_lock(lock_fd, 0, SEEK_SET, 0);


    val = fcntl(new_fd, F_GETFL, 0);
    fcntl(new_fd, F_SETFL, val | O_NONBLOCK);



    
    iconnectionnew(loop, new_fd);


end:

    return;

error:

    return;
}






static void
isigcb(struct ev_loop *loop, ev_signal *w, int revents) {
    puts("signal");
    ev_unloop(loop, EVUNLOOP_ALL);
}






static int
iworker(int sockfd) {



    struct ev_loop *loop = ev_default_loop(0);


    ev_io sockw;
    ev_io_init(&sockw, iacceptcb, sockfd, EV_READ);
    ev_set_priority(&sockw, EV_MAXPRI);
    ev_io_start(loop, &sockw);


    ev_signal exitsig;
    ev_signal_init(&exitsig, isigcb, SIGINT);
    ev_signal_start(loop, &exitsig);
    ev_unref(loop);


    ev_loop(loop, 0);


    return 0;

}




int
main(int argc, char **argv) {
    int                 sockfd;
    struct sockaddr_in  sock_addr;
    socklen_t len;
   



    int val;



    pid_t       pid[WORKERS];
    pid_t      *p;
    


    if (!(ipool = ipoolnew(DEFAULTPOOLSIZE))) {
        perror("ipoolnew");
        goto error;
    }

    if (!(imodules = iarraynew(ipool, 10, sizeof(IMODULE*)))) {
        perror("iarraynew");
        goto error;
    }

    ihttptophandler = NULL;
    ihttptopheaderfilter = NULL;
    ihttptopbodyfilter = NULL;





    /* init handlers in reverse order */
    imodulenew(&ifilemodule, ipool);

    /* init filters in reverse order */
    imodulenew(&ihttpoutputmodule, ipool);
    /*imodulenew(&itestmodule, ipool);*/
















    /* init http headers */
    {
        IHTTPHEADER            *h;
        IHTTPHEADER           **hh;

        for (h = ihttpheadersin; h->name.data; h++);

        ihttpheadersinhash = ihashnew(ipool, h - ihttpheadersin, sizeof(IHTTPHEADER*), (h - ihttpheadersin) * 2);


        for (h = ihttpheadersin; h->name.data; h++) {
            hh = ihashput(ihttpheadersinhash, ihashkey2(h->name.data, h->name.len, 1));
            *hh = h;
        }
    }






    {
#define ACCEPT_LOCK     "/tmp/http_lockXXXXXX"
        char    lock_file[sizeof(ACCEPT_LOCK)+1];
        
        strncpy(lock_file, ACCEPT_LOCK, sizeof(lock_file));

        /*if (!mktemp(lock_file)) {
            perror("mktemp");
            goto error;
        }

        if ((lock_fd = open(lock_file, O_CREAT | O_WRONLY, S_IROTH | S_IWOTH | S_IXOTH)) == -1) {
            perror("open");
            goto error;
        }*/
        if ((lock_fd = mkstemp(lock_file)) == -1) {
            perror("mkstemp");
            goto error;
        }

        if(unlink(lock_file) == -1) {
            perror("unlink");
            goto error;
        }


    }













    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        goto error;
    }





    val = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, val | O_NONBLOCK);





    val = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val)) == -1) {
        perror("setsockopt");
        goto error;
    }


    len = sizeof(ICONNECTIONRCVBUF);
    if (getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &ICONNECTIONRCVBUF, &len) == -1) {
        perror("getsockopt");
        goto error;
    }
    if (ICONNECTIONRCVBUF > 4096)
        ICONNECTIONRCVBUF = 4096;




    /* TODO test app works incorrectly */
    val = 5;
    if (setsockopt(sockfd, IPPROTO_TCP, TCP_DEFER_ACCEPT, &val, sizeof(val)) == -1) {
        perror("setsockopt");
        goto error;
    }



    sock_addr.sin_family        = AF_INET;
    sock_addr.sin_port          = htons(PORT);
    sock_addr.sin_addr.s_addr   = INADDR_ANY;
    memset(sock_addr.sin_zero, '\0', sizeof sock_addr.sin_zero);
    len = sizeof(sock_addr);

    if (bind(sockfd, (struct sockaddr*)&sock_addr, len) == -1) {
        perror("bind");
        goto error;
    }



    if (listen(sockfd, BACKLOG) == -1) {
        perror("listen");
        goto error;
    }



    p = pid;

#if 1
    while (p < pid + WORKERS) {

        *p = fork();

        if (*p < 0)
            goto error;
        else if (*p == 0) {
            return iworker(sockfd);
        }

        p++;
    }
#else
    if (iworker(sockfd))
        goto error;
#endif


    ipooldel(ipool);


    return 0;

error:
    
    return 1;
}
