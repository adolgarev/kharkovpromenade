#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>



#include "../http.h"




static int_t itestmoduleinit(void);
static int_t itesthandler(IHTTP *r);
static int_t itestheaderfilter(IHTTP *r);
static int_t itestbodyfilter(IHTTP *r, ICHAIN *chain);


static ihttphandler      ihttpnexthandler;
static ihttpheaderfilter ihttpnextheaderfilter;
static ihttpbodyfilter   ihttpnextbodyfilter;


IMODULE itestmodule = {
    IMODULE_V1,
    
    itestmoduleinit,

    IMODULE_V1_PADDING
};




static int_t
itestmoduleinit(void) {
    ihttpnexthandler = ihttptophandler;
    ihttptophandler = itesthandler;

    ihttpnextheaderfilter = ihttptopheaderfilter;
    ihttptopheaderfilter = itestheaderfilter;

    ihttpnextbodyfilter = ihttptopbodyfilter;
    ihttptopbodyfilter = itestbodyfilter;

    return 0;
}




static int_t
itesthandler(IHTTP *r) {


    /* DEBUG */

#if 1
    {
        ICHAIN *c;
        IBUF   *b;



        if (r->headers_out.content_type == NULL) {
            if (!(r->headers_out.content_type = ilistpush(r->headers_out.headers)))
                return 1;

            r->headers_out.content_type->key.data = "Content-Type";
            r->headers_out.content_type->key.len = sizeof("Content-Type")-1;
        }

        r->headers_out.content_type->value.data = "text/plain";
        r->headers_out.content_type->value.len = sizeof("text/plain")-1;





        r->headers_out.status = 200;
        r->headers_out.status_line.data = "OK";
        r->headers_out.status_line.len = 2;

        if (ihttptopheaderfilter(r))
            return 1;

        if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
            return 1;
        if (!(b = ibufnewtemp(r->pool, 10)))
            return 1;
        c->buf = b;
        memcpy(b->last, "Welcome1!\n", 10);
        b->last += 10;
        b->flush = 1;
        if (ihttptopbodyfilter(r, c))
            return 1;

        if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
            return 1;
        if (!(b = ibufnewtemp(r->pool, 10)))
            return 1;
        c->buf = b;
        memcpy(b->last, "Welcome2!\n", 10);
        b->last += 10;
        b->flush = 1;
        b->last_buf = 1;
        if (ihttptopbodyfilter(r, c))
            return 1;

        return 0;
    }
#endif


    return ihttpnexthandler(r);
}


static int_t
itestheaderfilter(IHTTP *r) {

    return ihttpnextheaderfilter(r);
}


static int_t
itestbodyfilter(IHTTP *r, ICHAIN *chain) {
    
    return ihttpnextbodyfilter(r, chain);
}


