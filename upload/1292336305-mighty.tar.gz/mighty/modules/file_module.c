#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#define __USE_GNU
#include <fcntl.h>


#include "../config.h"
#include "../http.h"




static int_t ifilemoduleinit(void);
static int_t ifilehandler(IHTTP *r);


static ihttphandler      ihttpnexthandler;


IMODULE ifilemodule = {
    IMODULE_V1,
    
    ifilemoduleinit,

    IMODULE_V1_PADDING
};







static int_t
ifilemoduleinit(void) {
    ihttpnexthandler = ihttptophandler;
    ihttptophandler = ifilehandler;

    return 0;
}




static int_t
ifilehandler(IHTTP *r) {



    ICHAIN     *out;
    IBUF       *buf;
    IFILE      *file;


#define FILENAMELEN 300
    char        tmp[FILENAMELEN];
    char       *p;








    out = ipoolcalloc(r->pool, sizeof(ICHAIN));
    file = ipoolcalloc(r->pool, sizeof(IFILE));




    p = tmp;
#ifdef X_ACCEL_REDIRECT
    strcpy(p, X_ACCEL_REDIRECT);
    p += sizeof(X_ACCEL_REDIRECT)-1;
#else
    strcpy(p, DOCUMENT_ROOT);
    p += sizeof(DOCUMENT_ROOT)-1;
#endif
    if (r->uri.data && r->uri.len)
        strncpy(p, r->uri.data, r->uri.len);    /* TODO unsafe */
    p += r->uri.len;
    *p = '\0';



#ifdef X_ACCEL_REDIRECT
    ITABLEELT      *e;

    if (!(e = ilistpush(r->headers_out.headers))) {
        goto error;
    }

    e->key.data = "X-Accel-Redirect";
    e->key.len = sizeof("X-Accel-Redirect")-1;

    e->value.len = sizeof(X_ACCEL_REDIRECT) + r->uri.len - 1;
    e->value.data = ipoolalloc(r->pool, e->value.len);
    if (e->value.data == NULL) {
        goto error;
    }
    memcpy(e->value.data, tmp, e->value.len);


    buf = ibufnewtemp(r->pool, 0);

    if (buf == NULL)
        goto error;

    buf->last_buf = 1;

    out->buf = buf;



    r->headers_out.status = 200;
    r->headers_out.status_line.len = 2;
    r->headers_out.status_line.data = "OK";


    if (ihttptopheaderfilter(r))
        goto error;

#else
    IPOOLCLEANUP   *cleanup;

    buf = ipoolcalloc(r->pool, sizeof(IBUF));

    file->name.data = tmp;
    file->name.len = sizeof(DOCUMENT_ROOT) + r->uri.len;

    if (stat(file->name.data, &file->stat)) {
        goto error;
    }


    if (!S_ISREG(file->stat.st_mode) && !S_ISLNK(file->stat.st_mode)) {
        goto error;
    }



    if ((file->fd = open(file->name.data, O_RDONLY | O_NOATIME)) == -1) {
        /* TODO O_LARGEFILE */
        /* The given file will be opened using 64-bit offsets, allowing files larger than two
           gigabytes to be opened. This is implied on 64-bit architectures. */

#if 0
        if (errno == EACCES || errno == ENOENT) {


            r->status = 404;


            if (ihttptopheaderfilter(r))
                goto error;
        }
        else
#endif
            goto error;
    }
    else {
        cleanup = ipoolcalloc2(r->pool, 0, ifileclose);
        cleanup->data = file;


        buf->file_pos = 0;
        buf->file_last = file->stat.st_size;
        buf->file = file;
        buf->in_file = 1;

        buf->last_buf = 1;

        out->buf = buf;



        r->headers_out.status = 200;
        r->headers_out.status_line.len = 2;
        r->headers_out.status_line.data = "OK";


        if (ihttptopheaderfilter(r))
            goto error;
    }

#endif

    return ihttptopbodyfilter(r, out);


    /*return ihttpnexthandler(r);*/

error:
    return 1;
}




