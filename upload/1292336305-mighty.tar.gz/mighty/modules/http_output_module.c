#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>



#include "../http.h"




static int_t ihttpoutputmoduleinit(void);
static int_t ihttpoutputheaderfilter(IHTTP *r);
static int_t ihttpoutputbodyfilter(IHTTP *r, ICHAIN *chain);


static ihttpheaderfilter    ihttpnextheaderfilter;
static ihttpbodyfilter      ihttpnextbodyfilter;


IMODULE ihttpoutputmodule = {
    IMODULE_V1,
    
    ihttpoutputmoduleinit,

    IMODULE_V1_PADDING
};





typedef struct {
    off_t       content_length_n;

    ICHAIN     *out;
    ICHAIN     *last;


    unsigned    headers_sent:1;
    unsigned    chunked:1;

} IHTTPOUTPUTMODULECTX;




static ISTR IHTTPLASTCHUNK  = {"0\r\n\r\n", 5};




int_t
ihttpoutputmoduleinit(void) {
    ihttpnextheaderfilter = ihttptopheaderfilter;
    ihttptopheaderfilter = ihttpoutputheaderfilter;

    ihttpnextbodyfilter = ihttptopbodyfilter;
    ihttptopbodyfilter = ihttpoutputbodyfilter;

    return 0;
}





static int_t
ihttpoutputheaderfilter(IHTTP *r) {

    IHTTPOUTPUTMODULECTX   *ctx;


    if (!(ctx = ipoolcalloc(r->pool, sizeof(IHTTPOUTPUTMODULECTX))))
        return 1;

    *ihttpmodulectx(r, &ihttpoutputmodule) = ctx;


    return 0;
}


static int_t
ihttpoutputbodyfilter(IHTTP *r, ICHAIN *chain) {

    IHTTPOUTPUTMODULECTX   *ctx;


    unsigned short  last_buf;
    unsigned short  flush;
    ICHAIN         *c;


    ctx = *ihttpmodulectx(r, &ihttpoutputmodule);

    if (!ctx->last) {
        ctx->out = chain;
        ctx->last = chain;
    }
    else
        ctx->last->next = chain;

    while (ctx->last->next)
        ctx->last = ctx->last->next;


    last_buf = 0;
    flush = 0;
    for (c = chain; c; c = c->next) {
        if (c->buf->in_file)
            ctx->content_length_n += c->buf->file_last - c->buf->file_pos;
        else
            ctx->content_length_n += c->buf->last - c->buf->pos;

        if (c->buf->last_buf) {
            last_buf = 1;
            break;
        }
        else if (c->buf->flush)
            flush = 1;
    }



    if (!last_buf && !flush)
        return 0;







    if (!ctx->headers_sent) {

        ITABLEELT      *e;
        u_char         *buf;
        IHTTPHEADERSOUT    *headers_out;


        headers_out = &r->headers_out;


        if (headers_out->content_length != NULL) {
            goto found;
        }


        if (!last_buf) { /* no Content-Length and no last_buf but flush is set */

            if (r->http_version <= 1000) {
                /* chunked response is not supported in HTTP 1.0 */
                r->connection->close = 1;



                if (headers_out->connection != NULL) {
                    goto found_connection;
                }

                if (!(headers_out->connection = ilistpush(headers_out->headers)))
                    goto error;

                headers_out->connection->key.data = "Connection";
                headers_out->connection->key.len = sizeof("Connection")-1;

found_connection:
                headers_out->connection->value.data = "close";
                headers_out->connection->value.len = sizeof("close")-1;
            }
            else {
                if (!(e = ilistpush(headers_out->headers)))
                    goto error;

                e->key.data = "Transfer-Encoding";
                e->key.len = sizeof("Transfer-Encoding")-1;

                e->value.data = "chunked";
                e->value.len = sizeof("chunked")-1;

                ctx->chunked = 1;
            }
        }
        else {

            if (!(headers_out->content_length = ilistpush(headers_out->headers)))
                goto error;

            headers_out->content_length->key.data = "Content-Length";
            headers_out->content_length->key.len = sizeof("Content-Length")-1;

            if (!(buf = ipoolalloc(r->pool, INT64_LEN)))
                goto error;

            headers_out->content_length->value.data = (char*) buf;
            headers_out->content_length->value.len = isprintfnum(buf, buf + INT64_LEN, ctx->content_length_n, 0, 0, 0);
        }

    }





    if (ctx->chunked) {

        if (ctx->content_length_n > 0) {
            ICHAIN *c;
            IBUF   *b;


            if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
                goto error;

            if (!(b = ibufnewtemp(r->pool, INT64_LEN + 2)))
                goto error;


            c->buf = b;
            c->next = ctx->out;
            ctx->out = c;


            b->last += isprintfnum(b->last, b->end, ctx->content_length_n, 0, 1, 0);
            *b->last++ = '\r';
            *b->last++ = '\n';


            if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
                goto error;

            if (!(b = ibufnewtemp(r->pool, 2)))
                goto error;

            *b->last++ = '\r';
            *b->last++ = '\n';

            c->buf = b;

            if (last_buf) {
                ctx->last->buf->last_buf = 0;
            }
            ctx->last->next = c;
            ctx->last = c;
        }


        if (last_buf) {
            ICHAIN *c;
            IBUF   *b;


            if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
                goto error;

            if (!(b = ipoolcalloc(r->pool, sizeof(IBUF))))
                goto error;


            c->buf = b;
            ctx->last->buf->last_buf = 0;
            ctx->last->next = c;
            ctx->last = c;

            b->start = (u_char*) IHTTPLASTCHUNK.data;
            b->pos = b->start;
            b->last = b->start + IHTTPLASTCHUNK.len;
            b->end = b->last + IHTTPLASTCHUNK.len;
            b->temporary = 1;
            b->last_buf = 1;
        }
    }





found:


    if (!ctx->headers_sent) {

        ICHAIN         *out;
        IBUF           *b;
        ITABLEELT      *elt;
        ILISTC          lc;


        if (!(out = ipoolcalloc(r->pool, sizeof(ICHAIN))))
            goto error;

        if (!(b = ibufnewtemp(r->pool, 1024)))
            goto error;

        out->buf = b;
        out->next = ctx->out;
        ctx->out = out;



        memcpy(b->last, "HTTP/1.", sizeof("HTTP/1.") - 1);
        b->last += sizeof("HTTP/1.") - 1;
        if (r->http_version > 1000)
            *b->last++ = '1';
        else
            *b->last++ = '0';
        *b->last++ = ' ';
        b->last += isprintfnum(b->last, b->end, r->headers_out.status, 0, 0, 0);
        *b->last++ = ' ';
        memcpy(b->last, r->headers_out.status_line.data, r->headers_out.status_line.len);
        b->last += r->headers_out.status_line.len;
        *b->last++ = '\r';
        *b->last++ = '\n';


        memset(&lc, 0, sizeof(ILISTC));
        while ((elt = ilistget(r->headers_out.headers, &lc)) != NULL) {

            size_t len = elt->key.len + elt->value.len + 4;

            if (b->last + len > b->end) {
                ICHAIN *c;

                if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
                    goto error;

                if (!(b = ibufnewtemp(r->pool, len > 1024 ? len : 1024)))
                    goto error;

                c->buf = b;

                c->next = out->next;
                out->next = c;
                out = c;

                /* try to increase buffer */
                /*if (r->pool->current < b->last && r->pool->current->end > b->last + len)
                  b->last += len;*/
            }


            memcpy(b->last, elt->key.data, elt->key.len);
            b->last += elt->key.len;
            *b->last++ = ':';
            *b->last++ = ' ';
            memcpy(b->last, elt->value.data, elt->value.len);
            b->last += elt->value.len;
            *b->last++ = '\r';
            *b->last++ = '\n';
        }


        if (b->last + 2 > b->end) {
            ICHAIN *c;

            if (!(c = ipoolcalloc(r->pool, sizeof(ICHAIN))))
                goto error;

            if (!(b = ibufnewtemp(r->pool, 2)))
                goto error;

            c->buf = b;

            c->next = out->next;
            out->next = c;
            out = c;

            /* try to increase buffer */
            /*if (r->pool->current < b->last && r->pool->current->end > b->last + len)
              b->last += len;*/
        }

        *b->last++ = '\r';
        *b->last++ = '\n';



        if (b->last < b->end) {
            ipoolfree2(r->pool, b->last, b->end - b->last);
            b->end = b->last;
        }



        ctx->headers_sent = 1;
    }


    c = ctx->out;
    ctx->content_length_n = 0;
    ctx->out = NULL;
    ctx->last = NULL;


    ihttpwrite(r, c);


    return 0;



error:

    return 1;
}

