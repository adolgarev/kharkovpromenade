
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stddef.h>

#include <netinet/tcp.h>
#include <netdb.h>

#include <sys/sendfile.h>



#include "config.h"
#include "http.h"



















ihttphandler        ihttptophandler;
ihttpheaderfilter   ihttptopheaderfilter;
ihttpbodyfilter     ihttptopbodyfilter;

IPOOL  *ipool;
IARRAY *imodules;




static int_t ihttpprocessheaderline(IHTTP *r, ITABLEELT *h, uint_t offset);
static int_t ihttpprocessuniqueheaderline(IHTTP *r, ITABLEELT *h, uint_t offset);
static int_t ihttpprocessconnection(IHTTP *r, ITABLEELT *h, uint_t offset);
static int_t ihttpprocessconnection(IHTTP *r, ITABLEELT *h, uint_t offset);
static int_t ihttpprocesscontentlength(IHTTP *r, ITABLEELT *h, uint_t offset);



IHTTPHEADER ihttpheadersin[] = {
     { istring("Host"), offsetof(IHTTPHEADERSIN, host),
                  ihttpprocessuniqueheaderline },
     { istring("Connection"), 0,
                  ihttpprocessconnection },
     { istring("Content-Type"), offsetof(IHTTPHEADERSIN, content_type),
                  ihttpprocessheaderline },
     { istring("Content-Length"), 0,
                  ihttpprocesscontentlength },
     { inullstring, 0, NULL }
};

IHASH           *ihttpheadersinhash;






























ICONNECTION*
iconnectionnew(struct ev_loop *loop, int new_fd) {

    
    ICONNECTION    *c;


    ev_io    *w;

    



    if (!(c = malloc(sizeof(ICONNECTION)))) {
        perror("malloc");
        goto error;
    }

    memset(c, 0, sizeof(ICONNECTION));

    
    if (!(w = malloc(sizeof(ev_io)))) {
        perror("malloc");
        goto error;
    }


    w->data = c;


    c->w        = w;


    c->loop     = loop;



    ev_io_init(w, iconnectioncb, new_fd, EV_READ);
    ev_io_start(loop, w);


    return c;

error:

    if (w)
        free(w);

    if (c)
        free(c);

    return NULL;
}



void
iconnectiondel(ICONNECTION *c) {

    IHTTP  *r, *n;


    for (r = c->current; r; ) {
        n = r->next;

        ihttpdel(r);

        r = n;
    }


    ev_io_stop(c->loop, c->w);

    close(c->w->fd);

    free(c->w);

    free(c);
}




void
iconnectioncb(struct ev_loop *loop, ev_io *w, int revents) {


    ICONNECTION    *c;
    IHTTP          *r;



    c = w->data;
    r = c->last;


    if (revents & EV_READ) {


        /* DEBUG */
        /*puts("EV_READ");*/


        if (!r || r->request_done) {
            if (!(r = ihttpnew(c)))
                goto error;

            if (!c->current)
                c->current = r;

            if (c->last)
                c->last->next = r;

            c->last = r;
        }


        if (r->handler(r))
            goto error;

    }




    if (revents & EV_WRITE) {
        /*puts("EV_WRITE");*/

        if (c->current)
            ihttpwrite(c->current, NULL);
    }





    return;


error:
    
    iconnectiondel(c);

    return;
}






















IHTTP*
ihttpnew(ICONNECTION *c) {


    IHTTP    *r;

    IPOOL    *pool;






    pool = ipoolnew(DEFAULTPOOLSIZE);

    if (!(r = ipoolcalloc(pool, sizeof(IHTTP)))) {
        perror("ipoolcalloc");
        goto error;
    }

    r->pool = pool;
    r->connection = c;





    if (!(r->ctx = ipoolcalloc(pool, imodules->nelts * sizeof(void*)))) {
        perror("ihashnew");
        goto error;
    }






    if (!(r->headers_in.headers = ilistnew(pool, 15, sizeof(ITABLEELT)))) {
        perror("ilistnew");
        goto error;
    }

    if (!(r->headers_out.headers = ilistnew(pool, 15, sizeof(ITABLEELT)))) {
        perror("ilistnew");
        goto error;
    }





    r->handler = ihttprequestlinehandler;


    if (!(r->header_in = ibufnewtemp(r->pool, REQUESTHEADERSIZE)))
        goto error;







    return r;


error:

    if (pool)
        ipooldel(pool);

    return NULL;
}



void
ihttpdel(IHTTP *r) {

    ipooldel(r->pool);
}


int_t
ihttprequestlinehandler(IHTTP *r) {
    IBUF       *b;
    ssize_t     numbytes;
    int_t       rc;


    b = r->header_in;



    if (b->last == b->end) {
        goto error; /* request too long */
    }


    numbytes = recv(r->connection->w->fd, b->last, b->end - b->last, 0);
    if (numbytes == -1) {

        if (errno == EAGAIN || errno == EWOULDBLOCK)
            return 0;

        perror("recv");
        goto error;
    }
    else if (!numbytes) {
        goto error;
    }



    b->last += numbytes;


    rc = ihttpparserequestline(r, b);


    if (rc == IAGAIN) {
        return 0;
    }


    if (!rc) {
        /* the request line has been parsed successfully */

        r->request_line.len = r->request_end - r->request_start;
        r->request_line.data = (char*) r->request_start;


        if (r->args_start) {
            r->uri.len = r->args_start - 1 - r->uri_start;
        }
        else {
            r->uri.len = r->uri_end - r->uri_start;
        }


        if (r->complex_uri || r->quoted_uri) {

            if (!(r->uri.data = ipoolalloc(r->pool, r->uri.len + 1)))
                goto error;


            if (ihttpparsecomplexuri(r)) {
                goto error;
            }

        }
        else {
            r->uri.data = (char*) r->uri_start;
        }


        r->unparsed_uri.len = r->uri_end - r->uri_start;
        r->unparsed_uri.data = (char*) r->uri_start;


        r->method_name.len = r->method_end - r->request_start + 1;
        r->method_name.data = r->request_line.data;


        if (r->http_protocol.data) {
            r->http_protocol.len = r->request_end - (u_char*) r->http_protocol.data;
        }


        if (r->uri_ext) {
            if (r->args_start) {
                r->exten.len = r->args_start - 1 - r->uri_ext;
            } else {
                r->exten.len = r->uri_end - r->uri_ext;
            }

            r->exten.data = (char*) r->uri_ext;
        }


        if (r->args_start && r->uri_end > r->args_start) {
            r->args.len = r->uri_end - r->args_start;
            r->args.data = (char*) r->args_start;
        }



        r->handler = ihttpheadershandler;

        if (b->pos < b->last) {
            r->handler(r);
        }
    }


    if (rc) {
        goto error;        
    }




    return 0;

error:
    return 1;
}

int_t
ihttpheadershandler(IHTTP *r) {
    IHTTP          *n;
    ICONNECTION    *c;
    IBUF           *b;
    ssize_t         numbytes;
    int_t           rc;
    uint_t          i;


    b = r->header_in;

    c = r->connection;


    if (b->last == b->end) {
        goto error; /* request too long */
    }


    if (b->pos == b->last) {
        numbytes = recv(r->connection->w->fd, b->last, b->end - b->last, 0);
        if (numbytes == -1) {

            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return 0;

            perror("recv");
            goto error;
        }
        else if (!numbytes) {
            goto error;
        }

        b->last += numbytes;
    }





    while (b->pos < b->last) {
        rc = ihttpparseheaderline(r, b);

        if (rc == IAGAIN) {
            return 0;
        }

        if (!rc) {
            ITABLEELT          *h;
            IHTTPHEADER       **hh;
            IHASHC              hc;


            if (r->invalid_header)
                /* ignore */;

            h = ilistpush(r->headers_in.headers);

            if (!h) {
                goto error;
            }

            h->hash = r->header_hash;

            h->key.len = r->header_name_end - r->header_name_start;
            h->key.data = (char*) r->header_name_start;
            h->key.data[h->key.len] = '\0';

            h->value.len = r->header_end - r->header_start;
            h->value.data = (char*) r->header_start;
            h->value.data[h->value.len] = '\0';

            h->lowcase_key = ipoolalloc(r->pool, h->key.len);
            if (h->lowcase_key == NULL) {
                goto error;
            }

            if (h->key.len == r->lowcase_index) {
                memcpy(h->lowcase_key, r->lowcase_header, h->key.len);
            }
            else {
                for (i = 0; i < h->key.len; i++) {
                    h->lowcase_key[i] = istrtolower(h->key.data[i]);
                }
            }


            memset(&hc, 0, sizeof(IHASHC));
            while ((hh = ihashget2(ihttpheadersinhash, h->hash, &hc)) != NULL) {
                if (!istrncasecmp((*hh)->name.data, (*hh)->name.len, h->key.data, h->key.len)) {

                    if ((*hh)->handler(r, h, (*hh)->offset)) {
                        goto error;
                    }

                    break;
                }
            }
        }

        if (rc == IHEADERSDONE) {


            if (r->headers_in.connection_close == IHTTPCONNECTIONCLOSE
                    || (r->http_version <= 1000 && r->headers_in.connection_close != IHTTPCONNECTIONKEEP)) {
                
                r->connection->close = 1;
            }

            /* TODO POST, set appropriate r->handler */


            /* if packet contains more than one request */
            if (b->pos < b->last) {
                if (!(n = ihttpnew(c)))
                    goto error;

                c->last->next = n;

                c->last = n;

                memcpy(n->header_in->last, b->pos, b->last - b->pos);
                n->header_in->last += b->last - b->pos;
                b->last = b->pos;
            }
            else {
                n = NULL;
            }

            r->request_done = 1;


            if (ihttptophandler(r))
                goto error;




            if (n) {
                n->handler(n);
            }


            break;
        }

        if (rc) {
            goto error;
        }
    }


    return 0;

error:
    return 1;
}

int_t
ihttprequestbodyhandler(IHTTP *r) {
    return 0;
}







static uint32_t  usual[] = {
    0xffffdbfe, /* 1111 1111 1111 1111  1101 1011 1111 1110 */

                /* ?>=< ;:98 7654 3210  /.-, +*)( '&%$ #"!  */
    0x7fff37d6, /* 0111 1111 1111 1111  0011 0111 1101 0110 */

                /* _^]\ [ZYX WVUT SRQP  ONML KJIH GFED CBA@ */
    0xffffffff, /* 1111 1111 1111 1111  1111 1111 1111 1111 */

                /*  ~}| {zyx wvut srqp  onml kjih gfed cba` */
    0xffffffff, /* 1111 1111 1111 1111  1111 1111 1111 1111 */

    0xffffffff, /* 1111 1111 1111 1111  1111 1111 1111 1111 */
    0xffffffff, /* 1111 1111 1111 1111  1111 1111 1111 1111 */
    0xffffffff, /* 1111 1111 1111 1111  1111 1111 1111 1111 */
    0xffffffff  /* 1111 1111 1111 1111  1111 1111 1111 1111 */
};


#define istr3cmp(m, c0, c1, c2, c3)                                       \
    m[0] == c0 && m[1] == c1 && m[2] == c2

#define istr3Ocmp(m, c0, c1, c2, c3)                                       \
    m[0] == c0 && m[2] == c2 && m[3] == c3

#define istr4cmp(m, c0, c1, c2, c3)                                        \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3

#define istr5cmp(m, c0, c1, c2, c3, c4)                                    \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3 && m[4] == c4

#define istr6cmp(m, c0, c1, c2, c3, c4, c5)                                \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3                      \
        && m[4] == c4 && m[5] == c5

#define istr7cmp(m, c0, c1, c2, c3, c4, c5, c6, c7)                       \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3                      \
        && m[4] == c4 && m[5] == c5 && m[6] == c6

#define istr8cmp(m, c0, c1, c2, c3, c4, c5, c6, c7)                        \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3                      \
        && m[4] == c4 && m[5] == c5 && m[6] == c6 && m[7] == c7

#define istr9cmp(m, c0, c1, c2, c3, c4, c5, c6, c7, c8)                    \
    m[0] == c0 && m[1] == c1 && m[2] == c2 && m[3] == c3                      \
        && m[4] == c4 && m[5] == c5 && m[6] == c6 && m[7] == c7 && m[8] == c8













#define LF     (u_char) 10
#define CR     (u_char) 13
#define CRLF   "\x0d\x0a"

int_t
ihttpparserequestline(IHTTP *r, IBUF *b) {
    u_char  c, ch, *p, *m;
    enum {
        sw_start = 0,
        sw_method,
        sw_spaces_before_uri,
        sw_schema,
        sw_schema_slash,
        sw_schema_slash_slash,
        sw_host,
        sw_port,
        sw_after_slash_in_uri,
        sw_check_uri,
        sw_uri,
        sw_http_09,
        sw_http_H,
        sw_http_HT,
        sw_http_HTT,
        sw_http_HTTP,
        sw_first_major_digit,
        sw_major_digit,
        sw_first_minor_digit,
        sw_minor_digit,
        sw_spaces_after_digit,
        sw_almost_done
    } state;

    state = r->state;

    for (p = b->pos; p < b->last; p++) {
        ch = *p;

        switch (state) {

            /* HTTP methods: GET, HEAD, POST */
            case sw_start:
                r->request_start = p;

                if (ch == CR || ch == LF) {
                    break;
                }

                if (ch < 'A' || ch > 'Z') {
                    return IINVALIDREQUEST;
                }

                state = sw_method;
                break;

            case sw_method:
                if (ch == ' ') {
                    r->method_end = p - 1;
                    m = r->request_start;

                    switch (p - m) {

                        case 3:
                            if (istr3cmp(m, 'G', 'E', 'T', ' ')) {
                                r->method = IHTTPGET;
                                break;
                            }

                            if (istr3cmp(m, 'P', 'U', 'T', ' ')) {
                                r->method = IHTTPPUT;
                                break;
                            }

                            break;

                        case 4:
                            if (m[1] == 'O') {

                                if (istr3Ocmp(m, 'P', 'O', 'S', 'T')) {
                                    r->method = IHTTPPOST;
                                    break;
                                }

                                if (istr3Ocmp(m, 'C', 'O', 'P', 'Y')) {
                                    r->method = IHTTPCOPY;
                                    break;
                                }

                                if (istr3Ocmp(m, 'M', 'O', 'V', 'E')) {
                                    r->method = IHTTPMOVE;
                                    break;
                                }

                                if (istr3Ocmp(m, 'L', 'O', 'C', 'K')) {
                                    r->method = IHTTPLOCK;
                                    break;
                                }

                            } else {

                                if (istr4cmp(m, 'H', 'E', 'A', 'D')) {
                                    r->method = IHTTPHEAD;
                                    break;
                                }
                            }

                            break;

                        case 5:
                            if (istr5cmp(m, 'M', 'K', 'C', 'O', 'L')) {
                                r->method = IHTTPMKCOL;
                            }

                            if (istr5cmp(m, 'T', 'R', 'A', 'C', 'E')) {
                                r->method = IHTTPTRACE;
                            }

                            break;

                        case 6:
                            if (istr6cmp(m, 'D', 'E', 'L', 'E', 'T', 'E')) {
                                r->method = IHTTPDELETE;
                                break;
                            }

                            if (istr6cmp(m, 'U', 'N', 'L', 'O', 'C', 'K')) {
                                r->method = IHTTPUNLOCK;
                                break;
                            }

                            break;

                        case 7:
                            if (istr7cmp(m, 'O', 'P', 'T', 'I', 'O', 'N', 'S', ' '))
                            {
                                r->method = IHTTPOPTIONS;
                            }

                            break;

                        case 8:
                            if (istr8cmp(m, 'P', 'R', 'O', 'P', 'F', 'I', 'N', 'D'))
                            {
                                r->method = IHTTPPROPFIND;
                            }

                            break;

                        case 9:
                            if (istr9cmp(m,
                                        'P', 'R', 'O', 'P', 'P', 'A', 'T', 'C', 'H'))
                            {
                                r->method = IHTTPPROPPATCH;
                            }

                            break;
                    }

                    state = sw_spaces_before_uri;
                    break;
                }

                if (ch < 'A' || ch > 'Z') {
                    return IINVALIDREQUEST;
                }

                break;

                /* space* before URI */
            case sw_spaces_before_uri:

                if (ch == '/' ){
                    r->uri_start = p;
                    state = sw_after_slash_in_uri;
                    break;
                }

                c = (u_char) (ch | 0x20);
                if (c >= 'a' && c <= 'z') {
                    r->schema_start = p;
                    state = sw_schema;
                    break;
                }

                switch (ch) {
                    case ' ':
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_schema:

                c = (u_char) (ch | 0x20);
                if (c >= 'a' && c <= 'z') {
                    break;
                }

                switch (ch) {
                    case ':':
                        r->schema_end = p;
                        state = sw_schema_slash;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_schema_slash:
                switch (ch) {
                    case '/':
                        state = sw_schema_slash_slash;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_schema_slash_slash:
                switch (ch) {
                    case '/':
                        r->host_start = p + 1;
                        state = sw_host;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_host:

                c = (u_char) (ch | 0x20);
                if (c >= 'a' && c <= 'z') {
                    break;
                }

                if ((ch >= '0' && ch <= '9') || ch == '.' || ch == '-') {
                    break;
                }

                r->host_end = p;

                switch (ch) {
                    case ':':
                        state = sw_port;
                        break;
                    case '/':
                        r->uri_start = p;
                        state = sw_after_slash_in_uri;
                        break;
                    case ' ':
                        /*
                         * use single "/" from request line to preserve pointers,
                         * if request line will be copied to large client buffer
                         */
                        r->uri_start = r->schema_end + 1;
                        r->uri_end = r->schema_end + 2;
                        state = sw_http_09;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_port:
                if (ch >= '0' && ch <= '9') {
                    break;
                }

                switch (ch) {
                    case '/':
                        r->port_end = p;
                        r->uri_start = p;
                        state = sw_after_slash_in_uri;
                        break;
                    case ' ':
                        r->port_end = p;
                        /*
                         * use single "/" from request line to preserve pointers,
                         * if request line will be copied to large client buffer
                         */
                        r->uri_start = r->schema_end + 1;
                        r->uri_end = r->schema_end + 2;
                        state = sw_http_09;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

                /* check "/.", "//", "%" in URI */
            case sw_after_slash_in_uri:

                if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                    state = sw_check_uri;
                    break;
                }

                switch (ch) {
                    case ' ':
                        r->uri_end = p;
                        state = sw_http_09;
                        break;
                    case CR:
                        r->uri_end = p;
                        r->http_minor = 9;
                        state = sw_almost_done;
                        break;
                    case LF:
                        r->uri_end = p;
                        r->http_minor = 9;
                        goto done;
                    case '.':
                        r->complex_uri = 1;
                        state = sw_uri;
                        break;
                    case '%':
                        r->quoted_uri = 1;
                        state = sw_uri;
                        break;
                    case '/':
                        r->complex_uri = 1;
                        state = sw_uri;
                        break;
                    case '?':
                        r->args_start = p + 1;
                        state = sw_uri;
                        break;
                    case '#':
                        r->complex_uri = 1;
                        state = sw_uri;
                        break;
                    case '+':
                        r->plus_in_uri = 1;
                        break;
                    case '\0':
                        r->zero_in_uri = 1;
                        break;
                    default:
                        state = sw_check_uri;
                        break;
                }
                break;

                /* check "/", "%" in URI */
            case sw_check_uri:

                if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                    break;
                }

                switch (ch) {
                    case '/':
                        r->uri_ext = NULL;
                        state = sw_after_slash_in_uri;
                        break;
                    case '.':
                        r->uri_ext = p + 1;
                        break;
                    case ' ':
                        r->uri_end = p;
                        state = sw_http_09;
                        break;
                    case CR:
                        r->uri_end = p;
                        r->http_minor = 9;
                        state = sw_almost_done;
                        break;
                    case LF:
                        r->uri_end = p;
                        r->http_minor = 9;
                        goto done;
                    case '%':
                        r->quoted_uri = 1;
                        state = sw_uri;
                        break;
                    case '?':
                        r->args_start = p + 1;
                        state = sw_uri;
                        break;
                    case '#':
                        r->complex_uri = 1;
                        state = sw_uri;
                        break;
                    case '+':
                        r->plus_in_uri = 1;
                        break;
                    case '\0':
                        r->zero_in_uri = 1;
                        break;
                }
                break;

                /* URI */
            case sw_uri:

                if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                    break;
                }

                switch (ch) {
                    case ' ':
                        r->uri_end = p;
                        state = sw_http_09;
                        break;
                    case CR:
                        r->uri_end = p;
                        r->http_minor = 9;
                        state = sw_almost_done;
                        break;
                    case LF:
                        r->uri_end = p;
                        r->http_minor = 9;
                        goto done;
                    case '#':
                        r->complex_uri = 1;
                        break;
                    case '\0':
                        r->zero_in_uri = 1;
                        break;
                }
                break;

                /* space+ after URI */
            case sw_http_09:
                switch (ch) {
                    case ' ':
                        break;
                    case CR:
                        r->http_minor = 9;
                        state = sw_almost_done;
                        break;
                    case LF:
                        r->http_minor = 9;
                        goto done;
                    case 'H':
                        r->http_protocol.data = (char*) p;
                        state = sw_http_H;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_http_H:
                switch (ch) {
                    case 'T':
                        state = sw_http_HT;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_http_HT:
                switch (ch) {
                    case 'T':
                        state = sw_http_HTT;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_http_HTT:
                switch (ch) {
                    case 'P':
                        state = sw_http_HTTP;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

            case sw_http_HTTP:
                switch (ch) {
                    case '/':
                        state = sw_first_major_digit;
                        break;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

                /* first digit of major HTTP version */
            case sw_first_major_digit:
                if (ch < '1' || ch > '9') {
                    return IINVALIDREQUEST;
                }

                r->http_major = ch - '0';
                state = sw_major_digit;
                break;

                /* major HTTP version or dot */
            case sw_major_digit:
                if (ch == '.') {
                    state = sw_first_minor_digit;
                    break;
                }

                if (ch < '0' || ch > '9') {
                    return IINVALIDREQUEST;
                }

                r->http_major = r->http_major * 10 + ch - '0';
                break;

                /* first digit of minor HTTP version */
            case sw_first_minor_digit:
                if (ch < '0' || ch > '9') {
                    return IINVALIDREQUEST;
                }

                r->http_minor = ch - '0';
                state = sw_minor_digit;
                break;

                /* minor HTTP version or end of request line */
            case sw_minor_digit:
                if (ch == CR) {
                    state = sw_almost_done;
                    break;
                }

                if (ch == LF) {
                    goto done;
                }

                if (ch == ' ') {
                    state = sw_spaces_after_digit;
                    break;
                }

                if (ch < '0' || ch > '9') {
                    return IINVALIDREQUEST;
                }

                r->http_minor = r->http_minor * 10 + ch - '0';
                break;

            case sw_spaces_after_digit:
                switch (ch) {
                    case ' ':
                        break;
                    case CR:
                        state = sw_almost_done;
                        break;
                    case LF:
                        goto done;
                    default:
                        return IINVALIDREQUEST;
                }
                break;

                /* end of request line */
            case sw_almost_done:
                r->request_end = p - 1;
                switch (ch) {
                    case LF:
                        goto done;
                    default:
                        return IINVALIDREQUEST;
                }
        }
    }

    b->pos = p;
    r->state = state;

    return IAGAIN;

done:

    b->pos = p + 1;

    if (r->request_end == NULL) {
        r->request_end = p;
    }

    r->http_version = r->http_major * 1000 + r->http_minor;
    r->state = sw_start;

    if (r->http_version == 9 && r->method != IHTTPGET) {
        return IINVALIDREQUEST;
    }

    return 0;
}



#define ISUPPRESSWARN 1

int_t
ihttpparsecomplexuri(IHTTP *r) {
    u_char  c, ch, decoded, *p, *u;
    uint_t merge_slashes;
    enum {
        sw_usual = 0,
        sw_slash,
        sw_dot,
        sw_dot_dot,
        sw_quoted,
        sw_quoted_second
    } state, quoted_state;

#if (ISUPPRESSWARN)
    decoded = '\0';
    quoted_state = sw_usual;
#endif
    merge_slashes = 1;

    state = sw_usual;
    p = r->uri_start;
    u = (u_char*) r->uri.data;
    r->uri_ext = NULL;
    r->args_start = NULL;

    ch = *p++;

    while (p <= r->uri_end) {

        /*
         * we use "ch = *p++" inside the cycle, but this operation is safe,
         * because after the URI there is always at least one charcter:
         * the line feed
         */


        switch (state) {

        case sw_usual:

            if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                *u++ = ch;
                ch = *p++;
                break;
            }

            switch(ch) {
            case '/':
                r->uri_ext = NULL;
                state = sw_slash;
                *u++ = ch;
                break;
            case '%':
                quoted_state = state;
                state = sw_quoted;
                break;
            case '?':
                r->args_start = p;
                goto args;
            case '#':
                goto done;
            case '.':
                r->uri_ext = u + 1;
                *u++ = ch;
                break;
            case '+':
                r->plus_in_uri = 1;
            default:
                *u++ = ch;
                break;
            }

            ch = *p++;
            break;

        case sw_slash:

            if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                state = sw_usual;
                *u++ = ch;
                ch = *p++;
                break;
            }

            switch(ch) {
            case '/':
                if (!merge_slashes) {
                    *u++ = ch;
                }
                break;
            case '.':
                state = sw_dot;
                *u++ = ch;
                break;
            case '%':
                quoted_state = state;
                state = sw_quoted;
                break;
            case '?':
                r->args_start = p;
                goto args;
            case '#':
                goto done;
            case '+':
                r->plus_in_uri = 1;
            default:
                state = sw_usual;
                *u++ = ch;
                break;
            }

            ch = *p++;
            break;

        case sw_dot:

            if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                state = sw_usual;
                *u++ = ch;
                ch = *p++;
                break;
            }

            switch(ch) {
            case '/':
                state = sw_slash;
                u--;
                break;
            case '.':
                state = sw_dot_dot;
                *u++ = ch;
                break;
            case '%':
                quoted_state = state;
                state = sw_quoted;
                break;
            case '?':
                r->args_start = p;
                goto args;
            case '#':
                goto done;
            case '+':
                r->plus_in_uri = 1;
            default:
                state = sw_usual;
                *u++ = ch;
                break;
            }

            ch = *p++;
            break;

        case sw_dot_dot:

            if (usual[ch >> 5] & (1 << (ch & 0x1f))) {
                state = sw_usual;
                *u++ = ch;
                ch = *p++;
                break;
            }

            switch(ch) {
            case '/':
                state = sw_slash;
                u -= 4;
                if (u < (u_char*) r->uri.data) {
                    return IINVALIDREQUEST;
                }
                while (*(u - 1) != '/') {
                    u--;
                }
                break;
            case '%':
                quoted_state = state;
                state = sw_quoted;
                break;
            case '?':
                r->args_start = p;
                goto args;
            case '#':
                goto done;
            case '+':
                r->plus_in_uri = 1;
            default:
                state = sw_usual;
                *u++ = ch;
                break;
            }

            ch = *p++;
            break;


        case sw_quoted:
            r->quoted_uri = 1;

            if (ch >= '0' && ch <= '9') {
                decoded = (u_char) (ch - '0');
                state = sw_quoted_second;
                ch = *p++;
                break;
            }

            c = (u_char) (ch | 0x20);
            if (c >= 'a' && c <= 'f') {
                decoded = (u_char) (c - 'a' + 10);
                state = sw_quoted_second;
                ch = *p++;
                break;
            }

            return IINVALIDREQUEST;

        case sw_quoted_second:
            if (ch >= '0' && ch <= '9') {
                ch = (u_char) ((decoded << 4) + ch - '0');

                if (ch == '%') {
                    state = sw_usual;
                    *u++ = ch;
                    ch = *p++;
                    break;
                }

                if (ch == '#') {
                    *u++ = ch;
                    ch = *p++;

                } else if (ch == '\0') {
                    r->zero_in_uri = 1;
                }

                state = quoted_state;
                break;
            }

            c = (u_char) (ch | 0x20);
            if (c >= 'a' && c <= 'f') {
                ch = (u_char) ((decoded << 4) + c - 'a' + 10);

                if (ch == '?') {
                    *u++ = ch;
                    ch = *p++;

                } else if (ch == '+') {
                    r->plus_in_uri = 1;
                }

                state = quoted_state;
                break;
            }

            return IINVALIDREQUEST;
        }
    }

done:

    r->uri.len = u - (u_char*) r->uri.data;

    if (r->uri_ext) {
        r->exten.len = u - r->uri_ext;
        r->exten.data = (char*) r->uri_ext;
    }

    r->uri_ext = NULL;

    return 0;

args:

    while (p < r->uri_end) {
        if (*p++ != '#') {
            continue;
        }

        r->args.len = p - 1 - r->args_start;
        r->args.data = (char*) r->args_start;
        r->args_start = NULL;

        break;
    }

    r->uri.len = u - (u_char*) r->uri.data;

    if (r->uri_ext) {
        r->exten.len = u - r->uri_ext;
        r->exten.data = (char*) r->uri_ext;
    }

    r->uri_ext = NULL;

    return 0;
}



int_t
ihttpparseheaderline(IHTTP *r, IBUF *b) {
    u_char      c, ch, *p;
    uint_t  hash, i;
    uint_t allow_underscores;
    enum {
        sw_start = 0,
        sw_name,
        sw_space_before_value,
        sw_value,
        sw_space_after_value,
        sw_ignore_line,
        sw_almost_done,
        sw_header_almost_done
    } state;

    allow_underscores = 1;

    /* the last '\0' is not needed because string is zero terminated */

    static u_char  lowcase[] =
        "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
        "\0\0\0\0\0\0\0\0\0\0\0\0\0-\0\0" "0123456789\0\0\0\0\0\0"
        "\0abcdefghijklmnopqrstuvwxyz\0\0\0\0\0"
        "\0abcdefghijklmnopqrstuvwxyz\0\0\0\0\0"
        "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
        "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
        "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
        "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

    state = r->state;
    hash = r->header_hash;
    i = r->lowcase_index;

    for (p = b->pos; p < b->last; p++) {
        ch = *p;

        switch (state) {

        /* first char */
        case sw_start:
            r->invalid_header = 0;

            switch (ch) {
            case CR:
                r->header_end = p;
                state = sw_header_almost_done;
                break;
            case LF:
                r->header_end = p;
                goto header_done;
            default:
                state = sw_name;
                r->header_name_start = p;

                c = lowcase[ch];

                if (c) {
                    hash = ihashkey(0, c);
                    r->lowcase_header[0] = c;
                    i = 1;
                    break;
                }

                r->invalid_header = 1;

                break;

            }
            break;

        /* header name */
        case sw_name:
            c = lowcase[ch];

            if (c) {
                hash = ihashkey(hash, c);
                r->lowcase_header[i++] = c;
                i &= (IHTTPLCHEADERLEN - 1);
                break;
            }

            if (ch == '_') {
                if (allow_underscores) {
                    hash = ihashkey(hash, ch);
                    r->lowcase_header[i++] = ch;
                    i &= (IHTTPLCHEADERLEN - 1);

                } else {
                    r->invalid_header = 1;
                }

                break;
            }

            if (ch == ':') {
                r->header_name_end = p;
                state = sw_space_before_value;
                break;
            }

            if (ch == CR) {
                r->header_name_end = p;
                r->header_start = p;
                r->header_end = p;
                state = sw_almost_done;
                break;
            }

            if (ch == LF) {
                r->header_name_end = p;
                r->header_start = p;
                r->header_end = p;
                goto done;
            }


            r->invalid_header = 1;

            break;

        /* space* before header value */
        case sw_space_before_value:
            switch (ch) {
            case ' ':
                break;
            case CR:
                r->header_start = p;
                r->header_end = p;
                state = sw_almost_done;
                break;
            case LF:
                r->header_start = p;
                r->header_end = p;
                goto done;
            default:
                r->header_start = p;
                state = sw_value;
                break;
            }
            break;

        /* header value */
        case sw_value:
            switch (ch) {
            case ' ':
                r->header_end = p;
                state = sw_space_after_value;
                break;
            case CR:
                r->header_end = p;
                state = sw_almost_done;
                break;
            case LF:
                r->header_end = p;
                goto done;
            }
            break;

        /* space* before end of header line */
        case sw_space_after_value:
            switch (ch) {
            case ' ':
                break;
            case CR:
                state = sw_almost_done;
                break;
            case LF:
                goto done;
            default:
                state = sw_value;
                break;
            }
            break;

        /* ignore header line */
        case sw_ignore_line:
            switch (ch) {
            case LF:
                state = sw_start;
                break;
            default:
                break;
            }
            break;

        /* end of header line */
        case sw_almost_done:
            switch (ch) {
            case LF:
                goto done;
            case CR:
                break;
            default:
                return IINVALIDREQUEST;
            }
            break;

        /* end of header */
        case sw_header_almost_done:
            switch (ch) {
            case LF:
                goto header_done;
            default:
                return IINVALIDREQUEST;
            }
        }
    }

    b->pos = p;
    r->state = state;
    r->header_hash = hash;
    r->lowcase_index = i;

    return IAGAIN;

done:

    b->pos = p + 1;
    r->state = sw_start;
    r->header_hash = hash;
    r->lowcase_index = i;

    return 0;

header_done:

    b->pos = p + 1;
    r->state = sw_start;

    return IHEADERSDONE;
}



void
ihttpwrite(IHTTP *r, ICHAIN *out) {

    ICONNECTION    *con;
    IHTTP          *hc;
    ICHAIN         *c;




    ssize_t         numbytes;
#define IOVECSIZE   100
    struct iovec    iov[IOVECSIZE];
    struct iovec   *iovp;
    int             iovc;



    int             tcp_cork;







    tcp_cork = 0;





    if (out) {
        if (!r->last) {
            r->out = out;
            r->last = out;
        }
        else
            r->last->next = out;

        while (r->last->next)
            r->last = r->last->next;
    }





    con = r->connection;


    







    while (1) {

        hc = con->current;
        if (!hc)
            goto end;
        c = hc->out;
        if (!c)
            goto end;


        
        if (c->buf->in_file) {
            IBUF   *b;

            b = c->buf;


            while (1) {
                if (sendfile(con->w->fd, b->file->fd, &b->file_pos, b->file_last - b->file_pos) == -1) {
                    if (errno == EAGAIN || errno == EWOULDBLOCK)
                        goto end;

                    perror("sendfile");
                    goto error;
                }

                if (b->file_pos == b->file_last) {

                    if (b->last_buf) {
                        con->current = hc->next;
                        ihttpdel(hc);
                        hc = con->current;

                        if (!con->current)
                            con->last = NULL;

                        if (hc)
                            c = hc->out;
                        else
                            goto end;
                    }
                    else {
                        c = c->next;
                        hc->out = c;

                        if (hc->out == NULL) {
                            hc->last = NULL;
                            goto end;
                        }
                    }

                    break;
                }
            }
        }



        iovc = 0;
        /* slow */
        /*memset(iov, 0, sizeof(struct iovec) * IOVECSIZE);*/
        for (iovp = iov; c && iovp < iov + IOVECSIZE; iovp++) {

            if (c->buf->in_file) {
                if (!tcp_cork) {
                    tcp_cork = 1;
                    if (setsockopt(con->w->fd, IPPROTO_TCP, TCP_CORK, &tcp_cork, sizeof(tcp_cork)) == -1) {
                        perror("setsockopt");
                        goto error;
                    }
                }

                break;
            }

            iovp->iov_base = c->buf->pos;
            iovp->iov_len = c->buf->last - c->buf->pos;
            iovc++;

            if (c->buf->last_buf) {
                hc = hc->next;

                if (hc)
                    c = hc->out;
                else
                    break;
            }
            else
                c = c->next;
        }




        iovp = iov;
        while (iovc) {
            numbytes = writev(con->w->fd, iovp, iovc);
            if (numbytes == -1) {

                if (errno == EAGAIN || errno == EWOULDBLOCK)
                    goto end;

                perror("writev");
                goto error;
            }
            else {
                struct iovec   *iovpp;
                ssize_t         n;





                n = numbytes;


                hc = con->current;
                c = hc->out;
                while (c && !c->buf->in_file) {
                    if (c->buf->last - c->buf->pos <= n) {
                        n -= c->buf->last - c->buf->pos;
                        c->buf->pos = c->buf->last;

                        if (c->buf->last_buf) {
                            con->current = hc->next;
                            
                            ihttpdel(hc);
                            
                            hc = con->current;

                            if (!con->current)
                                con->last = NULL;

                            if (hc)
                                c = hc->out;
                            else
                                goto end;
                        }
                        else {
                            c = c->next;
                            hc->out = c;

                            if (hc->out == NULL) {
                                hc->last = NULL;
                                goto end;
                            }
                        }
                    }
                    else {
                        c->buf->pos += n;
                        break;
                    }
                }




                iovpp = iovp;
                while (iovpp < iovp + iovc) {
                    if (iovpp->iov_len <= numbytes) {
                        numbytes -= iovpp->iov_len;
                        iovpp++;
                    }
                    else {
                        iovpp->iov_base  += numbytes;
                        iovpp->iov_len   -= numbytes;
                        break;
                    }
                }

                if (iovpp == iovp + iovc)
                    break;
                else {
                    iovc -= iovpp - iovp;
                    iovp = iovpp;
                }
            }
        }
    }


end:

    if (tcp_cork) {
        tcp_cork = 0;
        if (setsockopt(con->w->fd, IPPROTO_TCP, TCP_CORK, &tcp_cork, sizeof(tcp_cork)) == -1) {
            perror("setsockopt");
            goto error;
        }
    }


    if (con->current == NULL && con->close)
        iconnectiondel(con);
    else {
        struct ev_loop *loop;
        ev_io      *w;

        loop = con->loop;
        w = con->w;

        if ((con->current == NULL || con->current->out == NULL)
                && (w->events & EV_WRITE)) {

            ev_io_stop(loop, w);
            ev_io_set(w, w->fd, EV_READ);
            ev_io_start(loop, w);
        }
        else if ((con->current != NULL && con->current->out != NULL)
                && !(w->events & EV_WRITE)) {

            ev_io_stop(loop, w);
            ev_io_set(w, w->fd, EV_READ | EV_WRITE);
            ev_io_start(loop, w);
        }
    }


    return;



error:

    iconnectiondel(con);

    return;
}


void**
ihttpmodulectx(IHTTP *r, IMODULE *m) {
    return r->ctx + m->index;
}


static int_t
ihttpprocessheaderline(IHTTP *r, ITABLEELT *h, uint_t offset) {
    ITABLEELT  **ph;

    ph = (ITABLEELT **) ((char *) &r->headers_in + offset);

    if (*ph == NULL) {
        *ph = h;
    }

    return 0;
}

static int_t
ihttpprocessuniqueheaderline(IHTTP *r, ITABLEELT *h, uint_t offset) {
    ITABLEELT  **ph;

    ph = (ITABLEELT **) ((char *) &r->headers_in + offset);

    if (*ph == NULL) {
        *ph = h;
        return 0;
    }

    return 1;
}


static int_t
ihttpprocessconnection(IHTTP *r, ITABLEELT *h, uint_t offset) {

    if (!istrncasecmp(h->value.data, h->value.len, "close", 5 - 1)) {
        r->headers_in.connection_close = IHTTPCONNECTIONCLOSE;
    }
    else if (!istrncasecmp(h->value.data, h->value.len, "keep-alive", 10 - 1)) {
        r->headers_in.connection_close = IHTTPCONNECTIONKEEP;
    }

    return 0;
}


static int_t
ihttpprocesscontentlength(IHTTP *r, ITABLEELT *h, uint_t offset) {

    r->headers_in.content_length_n = iatoof(h->value.data, h->value.len);

    return 0;
}










































IMODULE*
imodulenew(IMODULE *module, IPOOL *pool) {
    
    IMODULE   **m;

    module->pool = pool;
    module->index = imodules->nelts;

    if (!(m = iarraypush(imodules)))
        return NULL;

    *m = module;

    if (module->initmodule())
        return NULL;

    return *m;
}


