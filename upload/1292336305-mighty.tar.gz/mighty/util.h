#ifndef UTIL_H
#define UTIL_H



#include <inttypes.h>
#include <sys/types.h>
#include <sys/stat.h> 




typedef intptr_t        int_t;
typedef uintptr_t       uint_t;
typedef intptr_t        flag_t;





typedef struct IPOOLS       IPOOL;
typedef struct IBUFS        IBUF;
typedef struct ICHAINS      ICHAIN;
typedef struct IFILES       IFILE;
















typedef struct {
    char   *data;
    size_t  len;
} ISTR;

#define INT64_LEN   sizeof("-9223372036854775808") - 1
size_t isprintfnum(u_char *buf, u_char *last, uint64_t ui64, u_char zero, uint_t hexadecimal, uint_t width);
int istrncmp(char *s1, size_t len1, char *s2, size_t len2);
int istrncasecmp(char *s1, size_t len1, char *s2, size_t len2);
off_t iatoof(char *data, size_t len);
#define istrtolower(c)      (u_char) ((c >= 'A' && c <= 'Z') ? (c | 0x20) : c)
#define istrtoupper(c)      (u_char) ((c >= 'a' && c <= 'z') ? (c & ~0x20) : c)
#define istring(str)        { (char *) str, sizeof(str) - 1 }
#define inullstring         { NULL, 0 }








struct IBUFS {
    u_char          *pos;
    u_char          *last;
    off_t            file_pos;
    off_t            file_last;

    u_char          *start;         /* start of buffer */
    u_char          *end;           /* end of buffer */

    IFILE           *file;


    /* the buf's content could be changed */
    unsigned         temporary:1;

    /*
     * the buf's content is in a memory cache or in a read only memory
     * and must not be changed
     */
    unsigned         memory:1;

    /* the buf's content is mmap()ed and must not be changed */
    unsigned         mmap:1;

    unsigned         recycled:1;
    unsigned         in_file:1;
    unsigned         flush:1;
    unsigned         sync:1;
    unsigned         last_buf:1;

    unsigned         temp_file:1;

};

IBUF *ibufnewtemp(IPOOL *pool, size_t size);












struct ICHAINS {
     IBUF    *buf;
     ICHAIN  *next;
};



















struct IFILES {
    ISTR    name;
    int     fd;

    struct stat    stat;
};

void ifileclose(void *data);



































typedef struct IPOOLLARGES      IPOOLLARGE;
typedef struct IPOOLCLEANUPS    IPOOLCLEANUP;


struct IPOOLCLEANUPS {
    void (*del)(void *);
    void           *data;
    IPOOLCLEANUP   *next;
};


struct IPOOLLARGES {
    IPOOLLARGE     *next;
    void           *alloc;
};



struct IPOOLS {
    u_char         *last;
    u_char         *end;
    IPOOL          *current;
    IPOOL          *next;
    IPOOLLARGE     *large;
    IPOOLCLEANUP   *cleanup;
};



IPOOL *ipoolnew(size_t size);
void ipooldel(IPOOL *pool);
void *ipoolalloc(IPOOL *pool, size_t size);
void *ipoolcalloc(IPOOL *pool, size_t size);
IPOOLCLEANUP *ipoolalloc2(IPOOL *pool, size_t size, void (*del)(void *));
IPOOLCLEANUP *ipoolcalloc2(IPOOL *pool, size_t size, void (*del)(void *));
void *ipoolpush(IPOOL *pool, void *p);
IPOOLCLEANUP *ipoolpush2(IPOOL *pool, void *p, void (*del)(void *));
/*void *ipoolrealloc(IPOOL *p, void *p, size_t size);*/
void ipoolfree(IPOOL *pool, void *p);
void ipoolfree2(IPOOL *pool, void *p, size_t size);













typedef struct {
    void       *elts;
    uint_t      nelts;  /* number on elements */
    size_t      size;   /* size of an element */
    uint_t      nalloc; /* allocated memory */
    IPOOL      *pool;
} IARRAY;


IARRAY *iarraynew(IPOOL *p, uint_t n, size_t size);
void iarraydel(IARRAY *a);
void *iarraypush(IARRAY *a);
void *iarraypush2(IARRAY *a, uint_t n);











typedef struct ILISTPARTS  ILISTPART;

struct ILISTPARTS {
    void       *elts;   /* pointer to elements */
    uint_t      nelts;  /* number of used elements */
    ILISTPART  *next;   /* next part */
};


typedef struct {
    ILISTPART  *last;   /* last part */
    ILISTPART   part;   /* first part */
    size_t      size;   /* size of an element */
    uint_t      nalloc; /* number of allocated elements for one part */
    IPOOL      *pool;
} ILIST;


typedef struct {
    ILISTPART  *part;
    void       *elt;
} ILISTC;


ILIST *ilistnew(IPOOL *pool, uint_t n, size_t size);
void ilistdel(ILIST *l);
void *ilistpush(ILIST *l);
void *ilistget(ILIST *l, ILISTC *c);



















typedef struct {
    ISTR    key;
    ISTR    value;
} IHASHELT;



typedef struct IHASHES  IHASHE;

struct IHASHES {
    IHASHE     *next;
    u_char      data[0];
};



typedef struct {
    void       *elts;
    uint_t      nelts;      /* number of used elements */
    size_t      size;       /* size of an element */
    uint_t      nalloc;     /* number of allocated elements */
    IHASHE    **buckets;    /* pointers to elts */
    uint_t      nbuckets;   /* number of buckets */
    IPOOL      *pool;
} IHASH;



typedef struct {
    uint_t      key_hash;
    IHASHE     *elt;
} IHASHC;


IHASH *ihashnew(IPOOL *pool, uint_t n, size_t size, uint_t nbuckets);
void ihashdel(IHASH *h);
void *ihashput(IHASH *h, uint_t key_hash);
void *ihashget(IHASH *h, IHASHC *c);
void *ihashget2(IHASH *h, uint_t key_hash, IHASHC *c);

#define ihashkey(k, a)     ((a) + ((k) << 6) + ((k) << 16) - (k))
unsigned long ihashkey2(void *data, size_t len, unsigned short cs);

#endif
