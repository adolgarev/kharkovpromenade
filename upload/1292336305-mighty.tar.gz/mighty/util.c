
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>


#include "util.h"






















size_t
isprintfnum(u_char *buf, u_char *last, uint64_t ui64, u_char zero, uint_t hexadecimal, uint_t width) {
    u_char         *p, temp[INT64_LEN + 1];
    /*
     * we need temp[NGX_INT64_LEN] only,
     * but icc issues the warning
     */
    size_t          len;
    uint32_t        ui32;
    static u_char   hex[] = "0123456789abcdef";
    static u_char   HEX[] = "0123456789ABCDEF";

    p = temp + INT64_LEN;

    if (hexadecimal == 0) {

        ui32 = (uint32_t) ui64;

        if (ui32 < ui64) {
            do {
                *--p = (u_char) (ui64 % 10 + '0');
            } while (ui64 /= 10);
        }
        else {

            /*
             * To divide 64-bit numbers and to find remainders
             * on the x86 platform gcc and icc call the libc functions
             * [u]divdi3() and [u]moddi3(), they call another function
             * in its turn.  On FreeBSD it is the qdivrem() function,
             * its source code is about 170 lines of the code.
             * The glibc counterpart is about 150 lines of the code.
             *
             * For 32-bit numbers and some divisors gcc and icc use
             * a inlined multiplication and shifts.  For example,
             * unsigned "i32 / 10" is compiled to
             *
             *     (i32 * 0xCCCCCCCD) >> 35
             */


            do {
                *--p = (u_char) (ui32 % 10 + '0');
            } while (ui32 /= 10);
        }

    }
    else if (hexadecimal == 1) {

        do {

            /* the "(uint32_t)" cast disables the BCC's warning */
            *--p = hex[(uint32_t) (ui64 & 0xf)];

        } while (ui64 >>= 4);

    }
    else { /* hexadecimal == 2 */

        do {

            /* the "(uint32_t)" cast disables the BCC's warning */
            *--p = HEX[(uint32_t) (ui64 & 0xf)];

        } while (ui64 >>= 4);
    }

    /* zero or space padding */

    len = (temp + INT64_LEN) - p;

    while (len++ < width && buf < last) {
        *buf++ = zero;
    }

    /* number safe copy */

    len = (temp + INT64_LEN) - p;

    if (buf + len > last) {
        len = last - buf;
    }

    memcpy(buf, p, len);

    return len;
}


int istrncmp(char *s1, size_t len1, char *s2, size_t len2) {
    return strncmp(s1, s2, len1 < len2 ? len1 : len2);
}

int istrncasecmp(char *s1, size_t len1, char *s2, size_t len2) {
    return strncasecmp(s1, s2, len1 < len2 ? len1 : len2);
}


off_t
iatoof(char *data, size_t len) {
    off_t  value;

    if (len == 0)
        return -1;

    for (value = 0; len--; data++) {
        if (*data < '0' || *data > '9')
            return value;

        value = value * 10 + (*data - '0');
    }

    if (value < 0)
        return -1;
    else
        return value;
}





























IBUF* ibufnewtemp(IPOOL *pool, size_t size) {

    IBUF *b;

    b = ipoolcalloc(pool, sizeof(IBUF));
    if (b == NULL)
        return NULL;


    b->start = ipoolalloc(pool, size);
    if (b->start == NULL)
        return NULL;


    b->pos = b->start;
    b->last = b->start;
    b->end = b->last + size;
    b->temporary = 1;

    return b;
}






















void
ifileclose(void *data) {
    close(((IFILE*)data)->fd);
}





























IPOOL*
ipoolnew(size_t size) {
    IPOOL  *p;

    p = malloc(size);
    if (p == NULL)
        return NULL;

    p->last = (u_char *) p + sizeof(IPOOL);
    p->end = (u_char *) p + size;
    p->current = p;
    p->next = NULL;
    p->large = NULL;
    p->cleanup = NULL;

    return p;
}

void
ipooldel(IPOOL *pool) {

    IPOOL          *p, *n;
    IPOOLLARGE     *l;
    IPOOLCLEANUP   *c;


    for (c = pool->cleanup; c; c = c->next) {
        if (c->del)
            c->del(c->data);
    }

    for (l = pool->large; l; l = l->next) {

        if (l->alloc)
            free(l->alloc);
    }

    for (p = pool, n = pool->next; /* void */; p = n, n = n->next) {
        free(p);

        if (n == NULL)
            break;
    }
}



#define pagesize 8192
#define MAX_ALLOC_FROM_POOL  (pagesize - 1)
#define ALIGNMENT   sizeof(unsigned long)    /* platform word */
#define align_ptr(p, a)     (u_char *) (((uintptr_t) (p) + ((uintptr_t) a - 1)) & ~((uintptr_t) a - 1))
#define HAVE_NONALIGNED 1

void*
ipoolalloc(IPOOL *pool, size_t size) {
    u_char      *m;
    IPOOL       *p, *n, *current;
    IPOOLLARGE  *large;

    if (size <= (size_t) MAX_ALLOC_FROM_POOL
            && size <= (size_t) (pool->end - (u_char *) pool) - (size_t) align_ptr(sizeof(IPOOL), ALIGNMENT)) {

        p = pool->current;
        current = p;

        for (;;) {

#if (HAVE_NONALIGNED)

            /*
             * allow non-aligned memory blocks for small allocations (1, 2,
             * or 3 bytes) and for odd length strings (struct's have aligned
             * size)
             */

            if (size < sizeof(int) || (size & 1)) {
                m = p->last;

            } else
#endif

            {
                m = align_ptr(p->last, ALIGNMENT);
            }

            if ((size_t) (p->end - m) >= size) {
                p->last = m + size;

                return m;
            }

            if ((size_t) (p->end - m) < ALIGNMENT)
                current = p->next;

            if (p->next == NULL)
                break;

            p = p->next;
            pool->current = current;
        }

        /* allocate a new pool block */

        n = ipoolnew((size_t) (p->end - (u_char *) p));
        if (n == NULL)
            return NULL;

        pool->current = current ? current : n;

        p->next = n;
        m = align_ptr(n->last, ALIGNMENT);
        n->last = m + size;

        return m;
    }

    p = malloc(size);
    if (p == NULL)
        return NULL;


    large = ipoolcalloc(pool, sizeof(IPOOLLARGE));
    if (large == NULL) {
        free(p);
        return NULL;
    }

    large->alloc = p;
    large->next = pool->large;
    pool->large = large;

    return p;
}

void*
ipoolcalloc(IPOOL *pool, size_t size) {

    void *p;

    p = ipoolalloc(pool, size);
    if (p)
        memset(p, 0, size);

    return p;
}

IPOOLCLEANUP*
ipoolalloc2(IPOOL *pool, size_t size, void (*del)(void *)) {

    IPOOLCLEANUP   *c;

    if (!(c = ipoolalloc(pool, sizeof(IPOOLCLEANUP))))
        return NULL;


    if (size) {
        if (!(c->data = ipoolalloc(pool, size)))
            return NULL;
    }
    else
        c->data = NULL;

    c->del = del;

    c->next = pool->cleanup;
    pool->cleanup = c;

    return c;
}


IPOOLCLEANUP*
ipoolcalloc2(IPOOL *pool, size_t size, void (*del)(void *)) {

    IPOOLCLEANUP *c;


    if (!(c = ipoolalloc2(pool, size, del)))
        return NULL;

    if (size)
        memset(c->data, 0, size);

    return c;
}


void*
ipoolpush(IPOOL *pool, void *p) {
    IPOOLLARGE *large;
    
    large = ipoolcalloc(pool, sizeof(IPOOLLARGE));
    if (large == NULL)
        return NULL;

    large->alloc = p;
    large->next = pool->large;
    pool->large = large;

    return p;
}



IPOOLCLEANUP*
ipoolpush2(IPOOL *pool, void *p, void (*del)(void *)) {
    IPOOLCLEANUP *c;

    if (!ipoolpush(pool, p))
        return NULL;

    if (!(c = ipoolalloc2(pool, 0, del)))
        return NULL;

    c->data = p;

    return c;
}



void
ipoolfree(IPOOL *pool, void *p) {

    IPOOLLARGE  *l;

    for (l = pool->large; l; l = l->next) {
        if (p == l->alloc) {
            free(l->alloc);
            l->alloc = NULL;

            return;
        }
    }
}


void
ipoolfree2(IPOOL *pool, void *p, size_t size) {
    
    if ((u_char *) p + size == pool->current->last)
        pool->current->last -= size;
}
























IARRAY*
iarraynew(IPOOL *p, uint_t n, size_t size) {
    IARRAY *a;

    a = ipoolcalloc(p, sizeof(IARRAY));
    if (a == NULL)
        return NULL;

    a->elts = ipoolcalloc(p, n * size);
    if (a->elts == NULL)
        return NULL;


    a->nelts = 0;
    a->size = size;
    a->nalloc = n;
    a->pool = p;

    return a;
}

void
iarraydel(IARRAY *a) {

    IPOOL  *p;

    p = a->pool;

    ipoolfree2(p, a->elts, a->size * a->nalloc);

    ipoolfree2(p, a, sizeof(IARRAY));
}

void*
iarraypush(IARRAY *a) {
    void       *elt, *new;
    size_t      size;
    IPOOL      *p;

    if (a->nelts == a->nalloc) {

        /* the array is full */

        size = a->size * a->nalloc;

        p = a->pool;

        if ((u_char *) a->elts + size == p->last && p->last + a->size <= p->end) {
            /*
             * the array allocation is the last in the pool
             * and there is space for new allocation
             */

            p->last += a->size;
            a->nalloc++;

        }
        else {
            /* allocate a new array */

            new = ipoolcalloc(p, 2 * size);
            if (new == NULL)
                return NULL;

            memcpy(new, a->elts, size);
            a->elts = new;
            a->nalloc *= 2;
        }
    }

    elt = (u_char *) a->elts + a->size * a->nelts;
    a->nelts++;

    return elt;
}

void*
iarraypush2(IARRAY *a, uint_t n) {
    void       *elt, *new;
    size_t      size;
    uint_t      nalloc;
    IPOOL      *p;

    size = n * a->size;

    if (a->nelts + n > a->nalloc) {

        /* the array is full */

        p = a->pool;

        if ((u_char *) a->elts + a->size * a->nalloc == p->current->last && p->current->last + size <= p->current->end) {
            /*
             * the array allocation is the last in the pool
             * and there is space for new allocation
             */

            p->current->last += size;
            a->nalloc += n;

        }
        else {
            /* allocate a new array */

            nalloc = 2 * ((n >= a->nalloc) ? n : a->nalloc);

            new = ipoolcalloc(p, nalloc * a->size);
            if (new == NULL)
                return NULL;

            memcpy(new, a->elts, a->nelts * a->size);
            a->elts = new;
            a->nalloc = nalloc;
        }
    }

    elt = (u_char *) a->elts + a->size * a->nelts;
    a->nelts += n;

    return elt;
}























ILIST*
ilistnew(IPOOL *pool, uint_t n, size_t size) {
    ILIST  *list;

    list = ipoolcalloc(pool, sizeof(ILIST));
    if (list == NULL)
        return NULL;


    list->part.elts = ipoolcalloc(pool, n * size);
    if (list->part.elts == NULL)
        return NULL;

    list->part.nelts = 0;
    list->part.next = NULL;
    list->last = &list->part;
    list->size = size;
    list->nalloc = n;
    list->pool = pool;

    return list;
}

void
ilistdel(ILIST *l) {

    IPOOL  *p;

    p = l->pool;

    ipoolfree2(p, l->part.elts, l->size * l->nalloc);

    ipoolfree2(p, l, sizeof(ILIST));
}

void*
ilistpush(ILIST *l) {
    void           *elt;
    ILISTPART      *last;

    last = l->last;

    if (last->nelts == l->nalloc) {

        /* the last part is full, allocate a new list part */

        last = ipoolcalloc(l->pool, sizeof(ILISTPART));
        if (last == NULL)
            return NULL;

        last->elts = ipoolcalloc(l->pool, l->nalloc * l->size);
        if (last->elts == NULL)
            return NULL;

        last->nelts = 0;
        last->next = NULL;

        l->last->next = last;
        l->last = last;
    }

    elt = (char *) last->elts + l->size * last->nelts;
    last->nelts++;

    return elt;
}


void*
ilistget(ILIST *l, ILISTC *c) {

    ILISTPART *p;


    if (c->elt) {
        p = c->part;

        c->elt = (u_char*) c->elt + l->size;
        if ((u_char*) c->elt >= (u_char*) p->elts + l->size * p->nelts) {
            p = p->next;

            if (!p || !p->nelts) {
                memset(c, 0, sizeof(ILISTC));
                return NULL;
            }

            c->part = p;
            c->elt = p->elts;
        }
    }
    else {
        p = &l->part;

        c->part = p;
        if (p->nelts)
            c->elt = p->elts;
        else
            memset(c, 0, sizeof(ILISTC));
    }

    return c->elt;
}



















IHASH*
ihashnew(IPOOL *pool, uint_t n, size_t size, uint_t nbuckets) {

    IHASH  *hash;

    hash = ipoolcalloc(pool, sizeof(IHASH));
    if (hash == NULL)
        return NULL;


    hash->elts = ipoolcalloc(pool, n * (sizeof(IHASHE) + size));
    if (hash->elts == NULL)
        return NULL;

    hash->buckets = ipoolcalloc(pool, nbuckets * sizeof(IHASHE*));
    if (hash->buckets == NULL)
        return NULL;

    hash->size = size;
    hash->nalloc = n;
    hash->nbuckets = nbuckets;
    hash->pool = pool;

    return hash;
}



void
ihashdel(IHASH *h) {

    IPOOL  *p;

    p = h->pool;

    ipoolfree2(p, h->buckets, h->nbuckets * sizeof(IHASHE*));

    ipoolfree2(p, h->elts, h->nalloc * (sizeof(IHASHE) + h->size));

    ipoolfree2(p, h, sizeof(IHASH));
}




void*
ihashput(IHASH *h, uint_t key_hash) {
    IHASHE     *elt, **bucket;

    bucket = h->buckets + (key_hash % h->nbuckets);

    if (h->nelts >= h->nalloc) {
        h->elts = ipoolcalloc(h->pool, h->nalloc * (sizeof(IHASHE) + h->size));
        if (h->elts == NULL)
            return NULL;

        h->nelts = 0;
    }

    elt = (IHASHE*) ((u_char*) h->elts + (sizeof(IHASHE) + h->size) * h->nelts++);

    elt->next = *bucket;
    *bucket = elt;

    return elt->data;
}



void*
ihashget(IHASH *h, IHASHC *c) {
    IHASHE  **p;

    if (c->elt) {
        if (c->elt->next) {
            c->elt = c->elt->next;
        }
        else {
            for (p = h->buckets + c->key_hash + 1; /* true */; p++) {
                if (p >= h->buckets + h->nbuckets) {
                    memset(c, 0, sizeof(IHASHC));
                    return NULL;
                }


                if (*p) {
                    c->elt = *p;
                    c->key_hash = p - h->buckets;
                    break;
                }
            }
        }
    }
    else {
        for (p = h->buckets; /* true */; p++) {
            if (p >= h->buckets + h->nbuckets) {
                memset(c, 0, sizeof(IHASHC));
                return NULL;
            }


            if (*p) {
                c->elt = *p;
                c->key_hash = p - h->buckets;
                break;
            }
        }

    }

    return c->elt->data;
}


void*
ihashget2(IHASH *h, uint_t key_hash, IHASHC *c) {

    if (c->elt)
        c->elt = c->elt->next;
    else {
        c->key_hash = key_hash % h->nbuckets;
        c->elt = h->buckets[c->key_hash];
    }

    if (c->elt)
        return c->elt->data;
    else {
        memset(c, 0, sizeof(IHASHC));
        return NULL;
    }
}






unsigned long
ihashkey2(void *data, size_t len, unsigned short cs) {
    unsigned long hash = 0;
    char   *p;

    p = data;

    while (p < (char *) data + len) {
        if (cs && *p >= 'A' && *p <= 'Z')
            hash = ihashkey(hash, *p++ - 'A' + 'a');
        else
            hash = ihashkey(hash, *p++);
    }

    return hash;
}

