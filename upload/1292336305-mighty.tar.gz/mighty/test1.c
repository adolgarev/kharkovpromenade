#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>



#include "util.h"


int main(int argc, char **argv) {

    IPOOL  *p;
    ILIST  *l;
    ILISTC  c;
    IHASH  *h;
    IHASHC  hc;


    char   *b;
    int i;
    int *ip;


    p = ipoolnew(1024);

    l = ilistnew(p, 5, sizeof(int));




    for (i = 0; i < 10; i++) {
        ip = ilistpush(l);
        if (i == 5)
            b = ipoolalloc(p, 100);
        *ip = i;
    }


    memset(&c, 0, sizeof(ILISTC));
    while ((ip = ilistget(l, &c)) != NULL) {
        printf("%d\n", *ip);
    }


    ilistdel(l);






    h = ihashnew(p, 3, sizeof(int), 10);


    *(int*) ihashput(h, ihashkey2("Test1", 5, 1)) = 1;
    *(int*) ihashput(h, ihashkey2("test1", 5, 1)) = 2;
    *(int*) ihashput(h, ihashkey2("Test2", 5, 1)) = 3;
    *(int*) ihashput(h, ihashkey2("Test2", 5, 1)) = 4;
    *(int*) ihashput(h, ihashkey2("Test2", 5, 1)) = 5;


    memset(&hc, 0, sizeof(IHASHC));
    while ((ip = ihashget(h, &hc)) != NULL) {
        printf("%d\n", *ip);
    }

    



    ihashdel(h);

    ipooldel(p);

    

    return 0;
}

