#ifndef HTTP_H
#define HTTP_H


#include <ev.h>

#include "util.h"









typedef struct IHTTPS       IHTTP;
typedef struct ICONNECTIONS ICONNECTION;
typedef struct IMODULES     IMODULE;











extern int ICONNECTIONRCVBUF;


struct ICONNECTIONS {
    IHTTP  *current;
    IHTTP  *last;

    struct ev_loop *loop;
    ev_io      *w;

    unsigned    close:1;
};


ICONNECTION* iconnectionnew(struct ev_loop *loop, int new_fd);
void iconnectiondel(ICONNECTION *c);
void iconnectioncb(struct ev_loop *loop, ev_io *w, int revents);























typedef struct {
    uint_t      hash;
    ISTR        key;
    ISTR        value;
    u_char     *lowcase_key;
} ITABLEELT;


typedef int_t (*ihttpheaderinhandler)(IHTTP *r, ITABLEELT *h, uint_t offset);

typedef struct {
    ISTR                        name;
    uint_t                      offset;
    ihttpheaderinhandler        handler;
} IHTTPHEADER;

extern IHTTPHEADER      ihttpheadersin[];
extern IHASH           *ihttpheadersinhash;



enum {
    IHTTPCONNECTIONNULL = 0,
    IHTTPCONNECTIONCLOSE,
    IHTTPCONNECTIONKEEP
};

typedef struct {
    ILIST          *headers;

    ITABLEELT                  *host;
    ITABLEELT                  *content_type;

    IARRAY                      cookies;

    off_t                       content_length_n;

    unsigned                    connection_close:2;
} IHTTPHEADERSIN;



typedef struct {
    ILIST          *headers;

    uint_t                      status;
    ISTR                        status_line;

    ITABLEELT                  *connection;
    ITABLEELT                  *content_length;
    ITABLEELT                  *content_type;

} IHTTPHEADERSOUT;



enum {
    IHTTPGET,
    IHTTPPUT,
    IHTTPPOST,
    IHTTPCOPY,
    IHTTPMOVE,
    IHTTPLOCK,
    IHTTPHEAD,
    IHTTPMKCOL,
    IHTTPTRACE,
    IHTTPDELETE,
    IHTTPUNLOCK,
    IHTTPOPTIONS,
    IHTTPPROPFIND,
    IHTTPPROPPATCH
};



#define IERROR          1
#define IAGAIN          2
#define IHEADERSDONE    3
#define IINVALIDREQUEST 4

typedef int_t (*ihttprequesthandler)(IHTTP *r);

struct IHTTPS {
    ICONNECTION    *connection;
    IHTTP          *next;


    void    **ctx;


    IPOOL    *pool;





    ICHAIN  *out;
    ICHAIN  *last;




    IHTTPHEADERSIN                headers_in;
    IHTTPHEADERSOUT               headers_out;



    ihttprequesthandler           handler;
    IBUF                         *header_in;



    uint_t                        method;
    uint_t                        http_version;
    ISTR                          http_protocol;
    ISTR                          request_line;
    ISTR                          uri;
    ISTR                          unparsed_uri;
    ISTR                          method_name;
    ISTR                          exten;
    ISTR                          args;



    /* URI with "/." and on Win32 with "//" */
    unsigned                          complex_uri:1;

    /* URI with "%" */
    unsigned                          quoted_uri:1;

    /* URI with "+" */
    unsigned                          plus_in_uri:1;

    /* URI with "\0" or "%00" */
    unsigned                          zero_in_uri:1;

    unsigned                          invalid_header:1;

    unsigned                          request_done:1;
    unsigned                          response_done:1;

    uint_t                            state;
    u_char                           *uri_start;
    u_char                           *uri_end;
    u_char                           *uri_ext;
    u_char                           *args_start;
    u_char                           *request_start;
    u_char                           *request_end;
    u_char                           *method_end;
    u_char                           *schema_start;
    u_char                           *schema_end;
    u_char                           *host_start;
    u_char                           *host_end;
    u_char                           *port_start;
    u_char                           *port_end;
    u_char                           *header_name_start;
    u_char                           *header_name_end;
    u_char                           *header_start;
    u_char                           *header_end;

    unsigned                          http_minor:16;
    unsigned                          http_major:16;

    uint_t                            header_hash;
    uint_t                            lowcase_index;
#define IHTTPLCHEADERLEN 32
    u_char                            lowcase_header[IHTTPLCHEADERLEN];
};


IHTTP* ihttpnew(ICONNECTION *c);
void ihttpdel(IHTTP *r);
void ihttpwrite(IHTTP *r, ICHAIN *out);
void** ihttpmodulectx(IHTTP *r, IMODULE *m);

int_t ihttpparserequestline(IHTTP *r, IBUF *b);
int_t ihttpparsecomplexuri(IHTTP *r);
int_t ihttpparseheaderline(IHTTP *r, IBUF *b);

int_t ihttprequestlinehandler(IHTTP *r);
int_t ihttpheadershandler(IHTTP *r);
int_t ihttprequestbodyhandler(IHTTP *r);
























extern IPOOL   *ipool;
extern IARRAY  *imodules;

#define IMODULE_V1          0, 1, NULL
#define IMODULE_V1_PADDING  0

typedef int_t (*ihttphandler)(IHTTP *r);
typedef int_t (*ihttpheaderfilter)(IHTTP *r);
typedef int_t (*ihttpbodyfilter)(IHTTP *r, ICHAIN *chain);


extern  ihttphandler        ihttptophandler;
extern  ihttpheaderfilter   ihttptopheaderfilter;
extern  ihttpbodyfilter     ihttptopbodyfilter;


/* handlers */
extern IMODULE ifilemodule;

/* filters */
extern IMODULE itestmodule;
extern IMODULE ihttpoutputmodule;


struct IMODULES {
    uint_t      index;

    uint_t      version;

    IPOOL    *pool;



    int_t             (*initmodule)(void);




    uint_t  spare0;
};


IMODULE* imodulenew(IMODULE *module, IPOOL *pool);















#endif
